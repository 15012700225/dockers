#!/bin/bash
docker build --rm=true --force-rm=true -t cif-docker cif-docker 
