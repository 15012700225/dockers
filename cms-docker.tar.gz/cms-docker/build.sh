#!/usr/bin/env bash
docker build -t rightctrl/tomcat:https .

