

docker run -d -p 5050:5000 --restart always --name docker-registry registry:latest

