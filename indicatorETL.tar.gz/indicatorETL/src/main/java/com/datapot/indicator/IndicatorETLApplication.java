package com.datapot.indicator;

import com.datapot.indicator.config.datasource.DynamicDataSourceRegister;
//import com.spring4all.mongodb.EnableMongoPlus;
import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;
import org.springframework.context.annotation.Import;
import org.springframework.transaction.annotation.EnableTransactionManagement;


@Import({ DynamicDataSourceRegister.class })
@SpringBootApplication
@EnableTransactionManagement
public class IndicatorETLApplication {
	public static void main(String[] args){
		SpringApplication.run(IndicatorETLApplication.class, args);
	}
}
