package com.datapot.indicator.bean;

import javax.persistence.*;
import java.io.Serializable;
import java.util.Date;

@Entity
@Table(name = "events")
public class SourceEvent implements Serializable {
    private static final long serialVersionUID = 1L;

    @Id
    private  Long id;

    @Column(name="org_id")
    private  Long orgId;

    @Column(name="date")
    private  Date date;

    @Column(name="info")
    private  String info;

    @Column(name="user_id")
    private  Long userId;

    @Column(name="uuid")
    private  String uuid;

    @Column(name="published")
    private  Integer published;

    @Column(name="analysis")
    private  Integer analysis;

    @Column(name="attribute_count")
    private  Long attributeCount;

    @Column(name="orgc_id")
    private  Long orgcId;

    @Column(name="timestamp")
    private  Long timestamp;

    @Column(name="distribution")
    private  Integer distribution;

    @Column(name="sharing_group_id")
    private  Long sharingGroupId;

    @Column(name="proposal_email_lock")
    private  Integer proposalEmailLock;

    @Column(name="locked")
    private  Integer locked;

    @Column(name="threat_level_id")
    private  Long threatLevelId;

    @Column(name="publish_timestamp")
    private  Long publishTimestamp;

    @Column(name="sighting_timestamp")
    private  Long sightingTimestamp;

    @Column(name="disable_correlation")
    private  Integer disableCorrelation;

    @Column(name="extends_uuid")
    private  String extendsUuid;

    public  Long  getId(){
        return  this.id;
    };
    public  void  setId(Long id){
        this.id=id;
    }

    public  Long  getOrgId(){
        return  this.orgId;
    };
    public  void  setOrgId(Long orgId){
        this.orgId=orgId;
    }

    public  Date  getDate(){
        return  this.date;
    };
    public  void  setDate(Date date){
        this.date=date;
    }

    public  String  getInfo(){
        return  this.info;
    };
    public  void  setInfo(String info){
        this.info=info;
    }

    public  Long  getUserId(){
        return  this.userId;
    };
    public  void  setUserId(Long userId){
        this.userId=userId;
    }

    public  String  getUuid(){
        return  this.uuid;
    };
    public  void  setUuid(String uuid){
        this.uuid=uuid;
    }

    public  Integer  getPublished(){
        return  this.published;
    };
    public  void  setPublished(Integer published){
        this.published=published;
    }

    public  Integer  getAnalysis(){
        return  this.analysis;
    };
    public  void  setAnalysis(Integer analysis){
        this.analysis=analysis;
    }

    public  Long  getAttributeCount(){
        return  this.attributeCount;
    };
    public  void  setAttributeCount(Long attributeCount){
        this.attributeCount=attributeCount;
    }

    public  Long  getOrgcId(){
        return  this.orgcId;
    };
    public  void  setOrgcId(Long orgcId){
        this.orgcId=orgcId;
    }

    public  Long  getTimestamp(){
        return  this.timestamp;
    };
    public  void  setTimestamp(Long timestamp){
        this.timestamp=timestamp;
    }

    public  Integer  getDistribution(){
        return  this.distribution;
    };
    public  void  setDistribution(Integer distribution){
        this.distribution=distribution;
    }

    public  Long  getSharingGroupId(){
        return  this.sharingGroupId;
    };
    public  void  setSharingGroupId(Long sharingGroupId){
        this.sharingGroupId=sharingGroupId;
    }

    public  Integer  getProposalEmailLock(){
        return  this.proposalEmailLock;
    };
    public  void  setProposalEmailLock(Integer proposalEmailLock){
        this.proposalEmailLock=proposalEmailLock;
    }

    public  Integer  getLocked(){
        return  this.locked;
    };
    public  void  setLocked(Integer locked){
        this.locked=locked;
    }

    public  Long  getThreatLevelId(){
        return  this.threatLevelId;
    };
    public  void  setThreatLevelId(Long threatLevelId){
        this.threatLevelId=threatLevelId;
    }

    public  Long  getPublishTimestamp(){
        return  this.publishTimestamp;
    };
    public  void  setPublishTimestamp(Long publishTimestamp){
        this.publishTimestamp=publishTimestamp;
    }

    public  Long  getSightingTimestamp(){
        return  this.sightingTimestamp;
    };
    public  void  setSightingTimestamp(Long sightingTimestamp){
        this.sightingTimestamp=sightingTimestamp;
    }

    public  Integer  getDisableCorrelation(){
        return  this.disableCorrelation;
    };
    public  void  setDisableCorrelation(Integer disableCorrelation){
        this.disableCorrelation=disableCorrelation;
    }

    public  String  getExtendsUuid(){
        return  this.extendsUuid;
    };
    public  void  setExtendsUuid(String extendsUuid){
        this.extendsUuid=extendsUuid;
    }
}
