package com.datapot.indicator.bean;

import javax.persistence.*;
import java.io.Serializable;
import java.util.Date;

@Entity
@Table(name = "event_indicators")
public class SourceEventIndicator implements Serializable {
    private static final long serialVersionUID = 1L;

    @Id
    private  Long id;

    @Column(name="event_id")
    private  long eventId;

    @Column(name="object_id")
    private  long objectId;

    @Column(name="object_relation")
    private  String objectRelation;

    @Column(name="category")
    private  String category;

    @Column(name="type")
    private  String type;

    @Column(name="value1")
    private  String value1;

    @Column(name="value2")
    private  String value2;

    @Column(name="to_ids")
    private  int toIds;

    @Column(name="uuid")
    private  String uuid;

    @Column(name="timestamp")
    private  long timestamp;

    @Column(name="distribution")
    private  int distribution;

    @Column(name="sharing_group_id")
    private  long sharingGroupId;

    @Column(name="comment")
    private  String comment;

    @Column(name="deleted")
    private  int deleted;

    @Column(name="disable_correlation")
    private  int disableCorrelation;


    @Column(name="provider")
    private String provider;

    @Column(name="description")
    private String description;

    public String getProvider() {
        return provider;
    }

    public void setProvider(String provider) {
        this.provider = provider;
    }

    public String getDescription() {
        return description;
    }

    public void setDescription(String description) {
        this.description = description;
    }

    public  long  getId(){
        return  this.id;
    };
    public  void  setId(long id){
        this.id=id;
    }

    public  long  getEventId(){
        return  this.eventId;
    };
    public  void  setEventId(long eventId){
        this.eventId=eventId;
    }

    public  long  getObjectId(){
        return  this.objectId;
    };
    public  void  setObjectId(long objectId){
        this.objectId=objectId;
    }

    public  String  getObjectRelation(){
        return  this.objectRelation;
    };
    public  void  setObjectRelation(String objectRelation){
        this.objectRelation=objectRelation;
    }

    public  String  getCategory(){
        return  this.category;
    };
    public  void  setCategory(String category){
        this.category=category;
    }

    public  String  getType(){
        return  this.type;
    };
    public  void  setType(String type){
        this.type=type;
    }

    public  String  getValue1(){
        return  this.value1;
    };
    public  void  setValue1(String value1){
        this.value1=value1;
    }

    public  String  getValue2(){
        return  this.value2;
    };
    public  void  setValue2(String value2){
        this.value2=value2;
    }

    public  int  getToIds(){
        return  this.toIds;
    };
    public  void  setToIds(int toIds){
        this.toIds=toIds;
    }

    public  String  getUuid(){
        return  this.uuid;
    };
    public  void  setUuid(String uuid){
        this.uuid=uuid;
    }

    public  long  getTimestamp(){
        return  this.timestamp;
    };
    public  void  setTimestamp(long timestamp){
        this.timestamp=timestamp;
    }

    public  int  getDistribution(){
        return  this.distribution;
    };
    public  void  setDistribution(int distribution){
        this.distribution=distribution;
    }

    public  long  getSharingGroupId(){
        return  this.sharingGroupId;
    };
    public  void  setSharingGroupId(long sharingGroupId){
        this.sharingGroupId=sharingGroupId;
    }

    public  String  getComment(){
        return  this.comment;
    };
    public  void  setComment(String comment){
        this.comment=comment;
    }

    public  int  getDeleted(){
        return  this.deleted;
    };
    public  void  setDeleted(int deleted){
        this.deleted=deleted;
    }

    public  int  getDisableCorrelation(){
        return  this.disableCorrelation;
    };
    public  void  setDisableCorrelation(int disableCorrelation){
        this.disableCorrelation=disableCorrelation;
    }
}
