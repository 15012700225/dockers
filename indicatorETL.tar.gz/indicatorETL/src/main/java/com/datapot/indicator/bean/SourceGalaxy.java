package com.datapot.indicator.bean;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.Id;
import javax.persistence.Table;
import java.io.Serializable;
import java.util.Date;

@Entity
@Table(name = "galaxies")
public class SourceGalaxy implements Serializable {
    private static final long serialVersionUID = 1L;

    @Id
    private  Long id;

    @Column(name="uuid")
    private  String uuid;

    @Column(name="name")
    private  String name;

    @Column(name="type")
    private  String type;

    @Column(name="description")
    private  String description;

    @Column(name="version")
    private  String version;

    @Column(name="icon")
    private  String icon;

    @Column(name="namespace")
    private  String namespace;

    @Column(name="kill_chain_order")
    private  String killChainOrder;

    public  Long  getId(){
        return  this.id;
    };
    public  void  setId(Long id){
        this.id=id;
    }

    public  String  getUuid(){
        return  this.uuid;
    };
    public  void  setUuid(String uuid){
        this.uuid=uuid;
    }

    public  String  getName(){
        return  this.name;
    };
    public  void  setName(String name){
        this.name=name;
    }

    public  String  getType(){
        return  this.type;
    };
    public  void  setType(String type){
        this.type=type;
    }

    public  String  getDescription(){
        return  this.description;
    };
    public  void  setDescription(String description){
        this.description=description;
    }

    public  String  getVersion(){
        return  this.version;
    };
    public  void  setVersion(String version){
        this.version=version;
    }

    public  String  getIcon(){
        return  this.icon;
    };
    public  void  setIcon(String icon){
        this.icon=icon;
    }

    public  String  getNamespace(){
        return  this.namespace;
    };
    public  void  setNamespace(String namespace){
        this.namespace=namespace;
    }

    public  String  getKillChainOrder(){
        return  this.killChainOrder;
    };
    public  void  setKillChainOrder(String killChainOrder){
        this.killChainOrder=killChainOrder;
    }

}
