package com.datapot.indicator.bean;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.Id;
import javax.persistence.Table;
import java.io.Serializable;
import java.util.Date;

@Entity
@Table(name = "galaxy_clusters ")
public class SourceGalaxyCluster implements Serializable {
    private static final long serialVersionUID = 1L;

    @Id
    private  Long id;

    @Column(name="uuid")
    private  String uuid;

    @Column(name="collection_uuid")
    private  String collectionUuid;

    @Column(name="type")
    private  String type;

    @Column(name="value")
    private  String value;

    @Column(name="tag_name")
    private  String tagName;

    @Column(name="description")
    private  String description;

    @Column(name="galaxy_id")
    private  Long galaxyId;

    @Column(name="source")
    private  String source;

    @Column(name="authors")
    private  String authors;

    @Column(name="version")
    private  Long version;

    public  Long  getId(){
        return  this.id;
    };
    public  void  setId(Long id){
        this.id=id;
    }

    public  String  getUuid(){
        return  this.uuid;
    };
    public  void  setUuid(String uuid){
        this.uuid=uuid;
    }

    public  String  getCollectionUuid(){
        return  this.collectionUuid;
    };
    public  void  setCollectionUuid(String collectionUuid){
        this.collectionUuid=collectionUuid;
    }

    public  String  getType(){
        return  this.type;
    };
    public  void  setType(String type){
        this.type=type;
    }

    public  String  getValue(){
        return  this.value;
    };
    public  void  setValue(String value){
        this.value=value;
    }

    public  String  getTagName(){
        return  this.tagName;
    };
    public  void  setTagName(String tagName){
        this.tagName=tagName;
    }

    public  String  getDescription(){
        return  this.description;
    };
    public  void  setDescription(String description){
        this.description=description;
    }

    public  Long  getGalaxyId(){
        return  this.galaxyId;
    };
    public  void  setGalaxyId(Long galaxyId){
        this.galaxyId=galaxyId;
    }

    public String getSource() {
        return source;
    }

    public void setSource(String source) {
        this.source = source;
    }

    public  String  getAuthors(){
        return  this.authors;
    };
    public  void  setAuthors(String authors){
        this.authors=authors;
    }

    public  Long  getVersion(){
        return  this.version;
    };
    public  void  setVersion(Long version){
        this.version=version;
    }
}
