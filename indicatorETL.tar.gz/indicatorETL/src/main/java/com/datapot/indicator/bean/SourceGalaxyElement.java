package com.datapot.indicator.bean;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.Id;
import javax.persistence.Table;
import java.io.Serializable;
import java.util.Date;

@Entity
@Table(name = "galaxy_clusters ")
public class SourceGalaxyElement implements Serializable {
    private static final long serialVersionUID = 1L;

    @Id
    private  Long id;

    @Column(name="galaxy_cluster_id")
    private  Long galaxyClusterId;

    @Column(name="key")
    private  String key;

    @Column(name="value")
    private  String value;

    public  Long  getId(){
        return  this.id;
    };
    public  void  setId(Long id){
        this.id=id;
    }

    public  Long  getGalaxyClusterId(){
        return  this.galaxyClusterId;
    };
    public  void  setGalaxyClusterId(Long galaxyClusterId){
        this.galaxyClusterId=galaxyClusterId;
    }

    public  String  getKey(){
        return  this.key;
    };
    public  void  setKey(String key){
        this.key=key;
    }

    public  String  getValue(){
        return  this.value;
    };
    public  void  setValue(String value){
        this.value=value;
    }
}
