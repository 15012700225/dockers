package com.datapot.indicator.bean;

import java.io.Serializable;

public class SourceIndicatorTagSummary implements Serializable {

    private long min;
    private long max;
    private long count;

    public long getMin() {
        return min;
    }

    public void setMin(long min) {
        this.min = min;
    }

    public long getMax() {
        return max;
    }

    public void setMax(long max) {
        this.max = max;
    }

    public long getCount() {
        return count;
    }

    public void setCount(long count) {
        this.count = count;
    }
}
