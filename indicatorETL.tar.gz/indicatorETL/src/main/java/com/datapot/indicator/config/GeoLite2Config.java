package com.datapot.indicator.config;

import org.springframework.beans.factory.annotation.Value;
import org.springframework.boot.context.properties.ConfigurationProperties;
import org.springframework.context.annotation.PropertySource;
import org.springframework.stereotype.Component;

@Component
@PropertySource(value = "classpath:geo-lite2.properties")
@ConfigurationProperties(prefix = "path")
public class GeoLite2Config {
    @Value("${path.geoLite2.city}")
    private String cityPath;

    public String getCityPath() {
        return cityPath;
    }

    public void setCityPath(String cityPath) {
        this.cityPath = cityPath;
    }
}