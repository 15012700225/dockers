package com.datapot.indicator.config;

import org.springframework.boot.context.properties.ConfigurationProperties;
import org.springframework.context.annotation.PropertySource;
import org.springframework.stereotype.Component;

import java.util.HashMap;
import java.util.Map;

@Component
@PropertySource(value = "classpath:intelStack-indicator-type-mapping.properties")
@ConfigurationProperties(prefix = "intelStack")
public class IntelStackIndicatorTypeMappingConfig {

    private Map<String, String> types = new HashMap<>();

    public Map<String, String> getTypes() {
        return types;
    }

    public void setTypes(Map<String, String> type) {
        this.types = type;
    }

}