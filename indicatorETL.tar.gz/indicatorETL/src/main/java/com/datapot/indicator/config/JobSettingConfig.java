package com.datapot.indicator.config;

import org.springframework.beans.factory.annotation.Value;
import org.springframework.boot.context.properties.ConfigurationProperties;
import org.springframework.context.annotation.PropertySource;
import org.springframework.stereotype.Component;

@Component
@PropertySource(value = "classpath:job-setting.properties")
@ConfigurationProperties(prefix = "job.setting")
public class JobSettingConfig {

    @Value("${job.setting.overlap}")
    private long overlap;

    @Value("${job.setting.stepDelta}")
    private long stepDelta;

    @Value("${job.setting.partitionSize}")
    private int partitionSize;

    @Value("${job.setting.consumerCount}")
    private int consumerCount;


    public Long getOverlap() {
        return overlap;
    }

    public void setOverlap(Long overlap) {
        this.overlap = overlap;
    }

    public Long getStepDelta() {
        return stepDelta;
    }

    public void setStepDelta(Long stepDelta) {
        this.stepDelta = stepDelta;
    }

    public int getPartitionSize() {
        return partitionSize;
    }

    public void setPartitionSize(int partitionSize) {
        this.partitionSize = partitionSize;
    }

    public int getConsumerCount() {
        return consumerCount;
    }

    public void setConsumerCount(int consumerCount) {
        this.consumerCount = consumerCount;
    }
}