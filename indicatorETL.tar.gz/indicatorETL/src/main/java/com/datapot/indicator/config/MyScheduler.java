package com.datapot.indicator.config;


import com.datapot.indicator.timer.CifETLJob;
import com.datapot.indicator.timer.IndicatorETLJob;
import com.datapot.indicator.timer.IntelStackETLJob;
import com.datapot.indicator.timer.MispETLJob;
import com.datapot.indicator.utils.QuartzManager;
import org.quartz.JobKey;
import org.quartz.SchedulerException;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.scheduling.quartz.SchedulerFactoryBean;
import org.springframework.stereotype.Component;

@Component
public class MyScheduler {

    private SchedulerFactoryBean schedulerFactoryBean;

    @Autowired
    public void setSchedulerFactoryBean(SchedulerFactoryBean schedulerFactoryBean) {
        this.schedulerFactoryBean = schedulerFactoryBean;
    }

    private static final Logger logger = LoggerFactory.getLogger(MyScheduler.class);

    public void scheduleJobs() throws SchedulerException {
        startJobs();
    }

    private void startJobs() throws SchedulerException {
        try {
            Object[] params = new Object[]{};
            indicatorJobs(params);
            //cifJobs(params);
            //intelStackJobs(params);
        } catch (Exception e) {
             logger.error(e.getMessage(), e);
        }
    }

    private void indicatorJobs(Object[] params) throws SchedulerException {
        //QuartzManager.addJob(schedulerFactoryBean, "MispETLJob", "ETLJob",
        //        "MispETLJobTrigger", "ETLTrigger", MispETLJob.class, "0/5 * * * * ? ", params);

        QuartzManager.addJob(schedulerFactoryBean, "IndicatorETLJob", "ETLJob",
                "IndicatorETLJobTrigger", "ETLTrigger", IndicatorETLJob.class, "0 0 1 * * ? ", params);

        //立即触发用于测试
        schedulerFactoryBean.getScheduler().triggerJob(JobKey.jobKey("IndicatorETLJob", "ETLJob"));
    }

   /* private void mispJobs(Object[] params) throws SchedulerException {
        //QuartzManager.addJob(schedulerFactoryBean, "MispETLJob", "ETLJob",
        //        "MispETLJobTrigger", "ETLTrigger", MispETLJob.class, "0/5 * * * * ? ", params);

        QuartzManager.addJob(schedulerFactoryBean, "MispIndicatorETLJob", "MISPETLJob",
                "MispIndicatorETLJobTrigger", "MISPETLTrigger", MispETLJob.class, "0 0 1 * * ? ", params);

        //立即触发用于测试
        schedulerFactoryBean.getScheduler().triggerJob(JobKey.jobKey("MispIndicatorETLJob", "MISPETLJob"));
    }


    private void cifJobs(Object[] params) throws SchedulerException{
        //QuartzManager.addJob(schedulerFactoryBean, "MispETLJob", "ETLJob",
        //        "MispETLJobTrigger", "ETLTrigger", MispETLJob.class, "0/5 * * * * ? ", params);

        QuartzManager.addJob(schedulerFactoryBean, "CifIndicatorETLJob", "CIFETLJob",
                "CifIndicatorETLJobTrigger", "CIFETLTrigger", CifETLJob.class, "0 0 1 * * ? ", params);

        //立即触发用于测试
        schedulerFactoryBean.getScheduler().triggerJob(JobKey.jobKey("CifIndicatorETLJob", "CIFETLJob"));
    }

    private void intelStackJobs(Object[] params) throws SchedulerException{
        //QuartzManager.addJob(schedulerFactoryBean, "MispETLJob", "ETLJob",
        //        "MispETLJobTrigger", "ETLTrigger", MispETLJob.class, "0/5 * * * * ? ", params);

        QuartzManager.addJob(schedulerFactoryBean, "IntelStackIndicatorETLJob", "INTELSTACKETLJob",
                "IntelStackIndicatorETLJobTrigger", "INTELSTACKETLTrigger", IntelStackETLJob.class, "0 0 1 * * ? ", params);

        //立即触发用于测试
        schedulerFactoryBean.getScheduler().triggerJob(JobKey.jobKey("IntelStackIndicatorETLJob", "INTELSTACKETLJob"));
    }*/
}
