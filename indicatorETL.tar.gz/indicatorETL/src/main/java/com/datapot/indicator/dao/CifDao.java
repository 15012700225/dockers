package com.datapot.indicator.dao;

import com.datapot.indicator.bean.SourceIndicator;
import com.datapot.indicator.bean.SourceRecordSummary;
import com.datapot.indicator.bean.SourceIndicatorTag;
import com.datapot.indicator.bean.SourceIndicatorTagSummary;
import com.datapot.indicator.config.datasource.TargetDataSource;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.BeanWrapper;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.jdbc.core.BeanPropertyRowMapper;
import org.springframework.jdbc.core.JdbcTemplate;
import org.springframework.jdbc.core.RowMapper;
import org.springframework.stereotype.Component;

import java.util.List;

@Component
public class CifDao {

    private JdbcTemplate jdbcTemplate;

    private static final Logger logger = LoggerFactory.getLogger(CifDao.class);

    @Autowired
    public void setJdbcTemplate(JdbcTemplate jdbcTemplate) {
        this.jdbcTemplate = jdbcTemplate;
    }


    @TargetDataSource(name = "cif")
    public SourceRecordSummary getIndicatorSummary(long left, long right){

        RowMapper<SourceRecordSummary> rowMapper = new BeanPropertyRowMapper<SourceRecordSummary>(SourceRecordSummary.class){
            @Override
            protected void initBeanWrapper(BeanWrapper bw) {
                super.initBeanWrapper(bw);
            }
        };

        String sql=String.format("select ifnull(min(strftime(\"%%s\",reporttime)),0) as min, ifnull(max(strftime(\"%%s\",reporttime)),0) as max, count(reporttime) as count from indicators where reporttime >= datetime(\"%d\", \"unixepoch\", \"localtime\") and reporttime < datetime(\"%d\", \"unixepoch\", \"localtime\")",left,right);

        logger.info(sql);
        return jdbcTemplate.queryForObject(sql, rowMapper);
    }

    @TargetDataSource(name = "cif")
    public List<SourceIndicator> getIndicatorsByReportTime(long left, long limit, long unused){
        //String sql=String.format("select * from indicators  where strftime(\"%%s\",reporttime) >= strftime(\"%%s\", datetime(\"%d\", \"unixepoch\")) and strftime(\"%%s\",reporttime) < strftime(\"%%s\", datetime(\"%d\", \"unixepoch\"))" , left,right);
        String sql=String.format("select *, strftime(\"%%s\",reporttime) as timestamp from indicators  where strftime(\"%%s\",reporttime) >= strftime(\"%%s\", datetime(\"%d\", \"unixepoch\")) order by reporttime limit %d" , left, limit);
        //logger.info(sql);

        RowMapper<SourceIndicator> rowMapper = new BeanPropertyRowMapper<>(SourceIndicator.class);
        return jdbcTemplate.query(sql, rowMapper, new Object[]{});
    }

    @TargetDataSource(name = "cif")
    public SourceIndicatorTagSummary getIndicatorTagSummary(){

        RowMapper<SourceIndicatorTagSummary> rowMapper = new BeanPropertyRowMapper<SourceIndicatorTagSummary>(SourceIndicatorTagSummary.class){
            @Override
            protected void initBeanWrapper(BeanWrapper bw) {
                super.initBeanWrapper(bw);
            }
        };

        String sql= "select ifnull(min(indicator_id),0) as min, ifnull(max(indicator_id),0) as max, count(indicator_id) as count from tags ";

        logger.info(sql);
        return jdbcTemplate.queryForObject(sql, rowMapper);
    }

    @TargetDataSource(name = "cif")
    public List<SourceIndicatorTag> getAttributeTagsByIndicatorIdBetween(long left, long right){

        RowMapper<SourceIndicatorTag> rowMapper = new BeanPropertyRowMapper<SourceIndicatorTag>(SourceIndicatorTag.class){
            @Override
            protected void initBeanWrapper(BeanWrapper bw) {
                super.initBeanWrapper(bw);
            }
        };

        String sql=String.format("select indicators.indicator as indicator_value, tags.tag as tag_name from tags left join indicators on indicators.id = tags.indicator_id  where  tags.indicator_id >= %d  and tags.indicator_id < %d", left, right);
        logger.info(sql);
        return jdbcTemplate.query(sql, rowMapper);
    }
}
