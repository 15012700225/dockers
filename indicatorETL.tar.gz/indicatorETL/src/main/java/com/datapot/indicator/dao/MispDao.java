package com.datapot.indicator.dao;

import com.datapot.indicator.bean.*;
import com.datapot.indicator.config.MispIndicatorTypeMappingConfig;
import com.datapot.indicator.config.datasource.TargetDataSource;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.BeanWrapper;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.jdbc.core.BeanPropertyRowMapper;
import org.springframework.jdbc.core.JdbcTemplate;
import org.springframework.jdbc.core.RowMapper;
import org.springframework.stereotype.Component;

import java.util.List;

@Component
public class MispDao {

    private JdbcTemplate jdbcTemplate;
    private MispIndicatorTypeMappingConfig indicatorTypeMapping;

    private static final Logger logger = LoggerFactory.getLogger(MispDao.class);

    @Autowired
    public void setJdbcTemplate(JdbcTemplate jdbcTemplate) {
        this.jdbcTemplate = jdbcTemplate;
    }
    @Autowired
    public void setIndicatorTypeMapping(MispIndicatorTypeMappingConfig indicatorTypeMapping) {
        this.indicatorTypeMapping = indicatorTypeMapping;
    }

    @TargetDataSource(name = "om")
    public SourceRecordSummary getIndicatorTagSummary(){

        RowMapper<SourceRecordSummary> rowMapper = new BeanPropertyRowMapper<SourceRecordSummary>(SourceRecordSummary.class){
            @Override
            protected void initBeanWrapper(BeanWrapper bw) {
                super.initBeanWrapper(bw);
            }
        };

        String sql=String.format("select IFNULL(min(id),0) as min,  IFNULL(max(id),0) as max, count(id) as count from attribute_tags");
        logger.info(sql);
        return jdbcTemplate.queryForObject(sql, rowMapper);
    }

    @TargetDataSource(name = "om")
    public SourceRecordSummary getIndicatorSummary(long left, long right){

        RowMapper<SourceRecordSummary> rowMapper = new BeanPropertyRowMapper<SourceRecordSummary>(SourceRecordSummary.class){
            @Override
            protected void initBeanWrapper(BeanWrapper bw) {
                super.initBeanWrapper(bw);
            }
        };

        String sql=String.format("select IFNULL(min(timestamp),0) as min,  IFNULL(max(timestamp),0) as max, count(timestamp) as count from attributes where timestamp between %d and %d", left,right);
        logger.info(sql);
        return jdbcTemplate.queryForObject(sql, rowMapper);
    }

    @TargetDataSource(name = "om")
    public List<SourceIndicator> getIndicatorsByTimestamp(long left, long limit, long unused){
        StringBuilder typeStrBuilder = new StringBuilder();
        for (String key : indicatorTypeMapping.getTypes().keySet()) {
            typeStrBuilder.append(String.format(",\"%s\"", key));
        }
        String typeStr = typeStrBuilder.substring(1);

        //String sql=String.format("select * from attributes where attributes.timestamp between %d and %d and attributes.type in (%s)" , left,right, typeStr);

        String sql=String.format("select attributes.value1 as indicator, attributes.type as itype, attributes.event_id as event_id,  events.info as description, attributes.timestamp as timestamp, organisations.name as provider from attributes left join events on events.id = attributes.event_id left join organisations on events.orgc_id = organisations.id where attributes.timestamp >= %d and attributes.type in (%s) order by attributes.timestamp limit %d", left,  typeStr,limit);

        logger.info(sql);

        RowMapper<SourceIndicator> rowMapper = new BeanPropertyRowMapper<>(SourceIndicator.class);

        return jdbcTemplate.query(sql, rowMapper, new Object[]{});
    }

    @TargetDataSource(name = "om")
    public List<SourceIndicatorTag> getIndicatorTags(long left, long right){

        RowMapper<SourceIndicatorTag> rowMapper = new BeanPropertyRowMapper<SourceIndicatorTag>(SourceIndicatorTag.class){
            @Override
            protected void initBeanWrapper(BeanWrapper bw) {
                super.initBeanWrapper(bw);
            }
        };

        StringBuilder typeStrBuilder = new StringBuilder();
        for (String key : indicatorTypeMapping.getTypes().keySet()) {
            typeStrBuilder.append(String.format(",\"%s\"", key));
        }

        String typeStr = typeStrBuilder.substring(1);

        //String sql=String.format("select attributes.value1 as indicator_value, concat(\"[\\\"\", GROUP_CONCAT(distinct replace(tags.name,\"\\\"\", \"'\") SEPARATOR '\\\",\\\"'),\"\\\"]\") as tag_name from attribute_tags left join attributes on attributes.id = attribute_tags.attribute_id left join tags on tags.id = attribute_tags.tag_id  group by attributes.value1;");

        String sql=String.format("select attributes.value1 as indicator_value, GROUP_CONCAT(distinct tags.name SEPARATOR ',') as tag_name from attribute_tags left join attributes on attributes.id = attribute_tags.attribute_id left join tags on tags.id = attribute_tags.tag_id where  attribute_tags.id between %d and %d  and attributes.type in (%s) group by attributes.value1;",left,right, typeStr);

        logger.info(sql);
        return jdbcTemplate.query(sql, rowMapper);
    }

    /////////////////////////////////////////////////////////////////
    /**event**/
    /////////////////////////////////////////////////////////////////

    @TargetDataSource(name = "om")
    public SourceRecordSummary getEventSummary(long left, long right){

        RowMapper<SourceRecordSummary> rowMapper = new BeanPropertyRowMapper<SourceRecordSummary>(SourceRecordSummary.class){
            @Override
            protected void initBeanWrapper(BeanWrapper bw) {
                super.initBeanWrapper(bw);
            }
        };

        String sql=String.format("select IFNULL(min(timestamp),0) as min,  IFNULL(max(timestamp),0) as max, count(timestamp) as count from events where timestamp between %d and %d", left,right);
        logger.info(sql);
        return jdbcTemplate.queryForObject(sql, rowMapper);
    }

    @TargetDataSource(name = "om")
    public List<SourceEvent> getEventsByTimestampBetween(long left, long right){
        StringBuilder typeStrBuilder = new StringBuilder();

        //String sql=String.format("select * from attributes where attributes.timestamp between %d and %d and attributes.type in (%s)" , left,right, typeStr);

        String sql=String.format("select * from events where events.timestamp between %d and %d" , left,right);

        logger.info(sql);

        RowMapper<SourceEvent> rowMapper = new BeanPropertyRowMapper<>(SourceEvent.class);

        return jdbcTemplate.query(sql, rowMapper, new Object[]{});
    }


    @TargetDataSource(name = "om")
    public List<SourceEventTag> getEventTags(){

        RowMapper<SourceEventTag> rowMapper = new BeanPropertyRowMapper<SourceEventTag>(SourceEventTag.class){
            @Override
            protected void initBeanWrapper(BeanWrapper bw) {
                super.initBeanWrapper(bw);
            }
        };

        String sql=String.format("select events.id as event_id, events.info as event_name, concat(\"[\\\"\", GROUP_CONCAT(distinct replace(tags.name,\"\\\"\", \"'\") SEPARATOR '\\\",\\\"'),\"\\\"]\") as tag_name from events left join event_tags on events.id = event_tags.event_id left join tags on event_tags.tag_id = tags.id group by events.id;");
        logger.info(sql);

        return jdbcTemplate.query(sql, rowMapper);
    }

    @TargetDataSource(name = "om")
    public List<SourceEventIndicator> getEventIndicatorsByTimestamp(long left, long limit, long unused){
        String sql=String.format("select attributes.*, organisations.name as provider, events.info as description from attributes left join events on events.id = attributes.event_id left join organisations on events.orgc_id = organisations.id where attributes.timestamp >= %d order by attributes.timestamp limit %d" , left,limit);

        logger.info(sql);

        RowMapper<SourceEventIndicator> rowMapper = new BeanPropertyRowMapper<>(SourceEventIndicator.class);

        return jdbcTemplate.query(sql, rowMapper, new Object[]{});
    }
    /////////////////////////////////////////////////////////////////
    /**galaxy**/
    /////////////////////////////////////////////////////////////////

    @TargetDataSource(name = "om")
    public  List<SourceGalaxy> getGalaxies(){

        RowMapper<SourceGalaxy> rowMapper = new BeanPropertyRowMapper<SourceGalaxy>(SourceGalaxy.class){
            @Override
            protected void initBeanWrapper(BeanWrapper bw) {
                super.initBeanWrapper(bw);
            }
        };

        String sql=String.format("select * from galaxies");
        logger.info(sql);

        return jdbcTemplate.query(sql, rowMapper);
    }

    @TargetDataSource(name = "om")
    public  List<SourceGalaxyCluster> getGalaxyClusters(){
        RowMapper<SourceGalaxyCluster> rowMapper = new BeanPropertyRowMapper<SourceGalaxyCluster>(SourceGalaxyCluster.class){
            @Override
            protected void initBeanWrapper(BeanWrapper bw) {
                super.initBeanWrapper(bw);
            }
        };

        String sql=String.format("select * from galaxy_clusters");
        logger.info(sql);

        return jdbcTemplate.query(sql, rowMapper);

    }
}
