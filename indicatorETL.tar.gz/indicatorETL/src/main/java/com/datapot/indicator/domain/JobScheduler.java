package com.datapot.indicator.domain;

import org.springframework.data.mongodb.core.mapping.Document;
import org.springframework.data.mongodb.core.mapping.Field;

import javax.persistence.Id;
import java.util.Date;

@Document(collection = "job_schedulers")
public class JobScheduler {
    @Id
    private String id;

    @Field("job_source")
    private String jobSource;

    @Field("job_settings")
    private String jobSettings;

    @Field("job_crontab_setting")
    private String job_crontab_setting;

    @Field("delta_timestamp")
    private Long deltaTimestamp;

    @Field("status")
    private Integer status;

    @Field("description")
    private String description;

    @Field("progressing_flag")
    private Integer progressingFlag;

    @Field("created_at")
    private Date createdAt;

    @Field("updated_at")
    private Date updatedAt;

    @Field("created_by")
    private String createdBy;

    @Field("updated_by")
    private String updatedBy;

    @Field("version")
    private Integer version;

    public JobScheduler(String jobSource){
        this.jobSource = jobSource;
        this.progressingFlag = 0;
        this.deltaTimestamp = 0L;
        this.version = 0;
    }

    public String getId() {
        return id;
    }

    public void setId(String id) {
        this.id = id;
    }

    public String getJobSource() {
        return jobSource;
    }

    public void setJobSource(String jobSource) {
        this.jobSource = jobSource;
    }

    public String getJobSettings() {
        return jobSettings;
    }

    public void setJobSettings(String jobSettings) {
        this.jobSettings = jobSettings;
    }

    public String getJob_crontab_setting() {
        return job_crontab_setting;
    }

    public void setJob_crontab_setting(String job_crontab_setting) {
        this.job_crontab_setting = job_crontab_setting;
    }

    public Long getDeltaTimestamp() {
        return deltaTimestamp;
    }

    public void setDeltaTimestamp(Long deltaTimestamp) {

        this.deltaTimestamp = deltaTimestamp;
    }

    public Integer getStatus() {
        return status;
    }

    public void setStatus(Integer status) {
        this.status = status;
    }

    public String getDescription() {
        return description;
    }

    public void setDescription(String description) {
        this.description = description;
    }

    public Integer getProgressingFlag() {
        return progressingFlag;
    }

    public void setProgressingFlag(Integer progressingFlag) {
        this.progressingFlag = progressingFlag;
    }

    public Date getCreatedAt() {
        return createdAt;
    }

    public void setCreatedAt(Date createdAt) {
        this.createdAt = createdAt;
    }

    public Date getUpdatedAt() {
        return updatedAt;
    }

    public void setUpdatedAt(Date updatedAt) {
        this.updatedAt = updatedAt;
    }

    public String getCreatedBy() {
        return createdBy;
    }

    public void setCreatedBy(String createdBy) {
        this.createdBy = createdBy;
    }

    public String getUpdatedBy() {
        return updatedBy;
    }

    public void setUpdatedBy(String updatedBy) {
        this.updatedBy = updatedBy;
    }

    public Integer getVersion() {
        return version;
    }

    public void setVersion(Integer version) {
        this.version = version;
    }
}
