package com.datapot.indicator.repository;

import com.datapot.indicator.bean.SourceEvent;
import com.datapot.indicator.bean.SourceEventIndicator;
import com.datapot.indicator.bean.SourceEventTag;

import com.datapot.indicator.domain.IndicatorProvider;
import com.mongodb.*;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.configurationprocessor.json.JSONArray;
import org.springframework.boot.configurationprocessor.json.JSONException;
import org.springframework.boot.configurationprocessor.json.JSONObject;
import org.springframework.data.mongodb.core.MongoTemplate;
import org.springframework.stereotype.Component;

import javax.persistence.Column;
import javax.persistence.Id;
import java.util.List;


//necessary imports


/**
 * spring data jpa实现数据访问层；
 */
@Component
public class EventRepository {
    private MongoTemplate mongoTemplate;
    @Autowired
    public void setMongoTemplate(MongoTemplate mongoTemplate) {
        this.mongoTemplate = mongoTemplate;
    }

    public void upsertEvents(List<SourceEvent> events){
        try {
            DBCollection collection = mongoTemplate.getDb().getCollection("events");
            BulkWriteOperation bulkWriteOperation = collection.initializeUnorderedBulkOperation();

            for (SourceEvent event : events) {
                BasicDBObject query = new BasicDBObject();
                query.append("event_id", event.getId());

                BulkWriteRequestBuilder bulkWriteRequestBuilder = bulkWriteOperation.find(query);
                BulkUpdateRequestBuilder updateReq = bulkWriteRequestBuilder.upsert();

                BasicDBObject update = new BasicDBObject();
                update.append("event_id", event.getId());
                update.append("org_id", event.getOrgId());
                update.append("date", event.getDate());
                update.append("info", event.getInfo());
                update.append("user_id", event.getUserId());
                update.append("uuid", event.getUuid());
                update.append("published", event.getPublished());
                update.append("analysis", event.getAnalysis());
                update.append("attribute_count", event.getAttributeCount());
                update.append("orgc_id", event.getOrgcId());
                update.append("timestamp", event.getTimestamp());
                update.append("distribution", event.getDistribution());
                update.append("sharing_group_id", event.getSharingGroupId());
                update.append("proposal_email_lock", event.getProposalEmailLock());
                update.append("locked", event.getLocked());
                update.append("threat_level_id", event.getThreatLevelId());
                update.append("publish_timestamp", event.getPublishTimestamp());
                update.append("sighting_timestamp", event.getSightingTimestamp());
                update.append("disable_correlation", event.getDisableCorrelation());
                update.append("extends_uuid", event.getExtendsUuid());
                updateReq.replaceOne(update);
            }

            BulkWriteResult result = bulkWriteOperation.execute();
        }catch (Exception e){
            e.printStackTrace();
        }

        ///////////////////////////////////////////////////////////////////
        /*for(Indicator indicator : indicators) {
            upsertIndicator(indicator);
        }*/
    }

    /*public void upsertIndicator(Indicator indicator){

        Query query = new Query();
        query.addCriteria(Criteria.where("indicator_value").is(indicator.getIndicatorValue()));

        Update update = new Update();
;
        update.set("indicator_type", indicator.getIndicatorType());
        update.set("confidence", indicator.getConfidence());
        update.set("country", indicator.getCountry());
        update.set("city", indicator.getCity());
        update.set("latitude", indicator.getLatitude());
        update.set("longitude", indicator.getLongitude());
        update.set("desciption", indicator.getDescription());

        //Date now = new Date();
        //update.setOnInsert("created_at",  now);
        //update.set("updated_at", now);

        mongoTemplate.upsert(query, update, Indicator.class);

    }*/

    public void upsertEventIndicators(List<SourceEventIndicator> eventIndicators){

        DBCollection collection = mongoTemplate.getDb().getCollection("event_indicators");
        BulkWriteOperation  bulkWriteOperation= collection.initializeUnorderedBulkOperation();

        for(SourceEventIndicator eventIndicator : eventIndicators) {
            BasicDBObject query = new BasicDBObject();
            query.append("event_id", eventIndicator.getEventId());
            query.append("indicator_value", eventIndicator.getValue1());

            BulkWriteRequestBuilder bulkWriteRequestBuilder = bulkWriteOperation.find(query);
            BulkUpdateRequestBuilder updateReq= bulkWriteRequestBuilder.upsert();

            BasicDBObject update = new BasicDBObject();
            update.append("event_id", eventIndicator.getEventId());
            update.append("indicator_value", eventIndicator.getValue1());


            update.append("object_id", eventIndicator.getObjectId());
            update.append("object_relation", eventIndicator.getObjectRelation());

            update.append("category", eventIndicator.getCategory());
            update.append("type", eventIndicator.getType());

            update.append("value1", eventIndicator.getValue1());
            update.append("value2", eventIndicator.getValue2());

            update.append("to_ids", eventIndicator.getToIds());
            update.append("uuid", eventIndicator.getUuid());

            update.append("distribution", eventIndicator.getDistribution());
            update.append("sharing_group_id", eventIndicator.getSharingGroupId());

            update.append("comment", eventIndicator.getComment());
            update.append("deleted", eventIndicator.getDeleted());

            update.append("disable_correlation", eventIndicator.getDisableCorrelation());

            updateReq.replaceOne(update);
        }

        BulkWriteResult result=bulkWriteOperation.execute();
    }

   /* public void upsertIndicatorProviders(List<IndicatorProvider> indicators){

        com.mongodb.DBCollection collection = mongoTemplate.getDb().getCollection("indicator_providers");
        BulkWriteOperation  bulkWriteOperation= collection.initializeUnorderedBulkOperation();

        for(Indicator indicator : indicators) {
            BasicDBObject query = new BasicDBObject();
            query.append("indicator_value", indicator.getIndicatorValue());
            query.append("provider", indicator.getProvider());
            query.append("report_time", indicator.getReportTime());

            BulkWriteRequestBuilder bulkWriteRequestBuilder = bulkWriteOperation.find(query);
            BulkUpdateRequestBuilder updateReq= bulkWriteRequestBuilder.upsert();

            BasicDBObject update = new BasicDBObject();
            update.append("indicator_value", indicator.getIndicatorValue());
            update.append("provider", indicator.getProvider());
            update.append("report_time", indicator.getReportTime());

            update.append("description", indicator.getDescription());
            update.append("event_id", indicator.getEventId());
            update.append("event_name", indicator.getEventName());

            updateReq.replaceOne(update);
        }

        BulkWriteResult result=bulkWriteOperation.execute();

        *//*for(Indicator indicator : indicators) {
            upsertIndicatorProvider(indicator);
        }*//*
    }*/


   /* public void upsertIndicatorProvider(Indicator indicator){
        Query query = new Query();
        query.addCriteria(Criteria.where("indicator_value").is(indicator.getIndicatorValue()));
        query.addCriteria(Criteria.where("provider").is(indicator.getProvider()));
        query.addCriteria(Criteria.where("report_time").is(indicator.getReportTime()));

        Update update = new Update();
        update.set("description", indicator.getDescription());

        //update.set("confidence", indicator.getConfidence());
        //update.set("country", indicator.getCountry());
        //update.set("city", indicator.getCity());
        //update.set("latitude", indicator.getLatitude());
        //update.set("longitude", indicator.getLongitude());
        mongoTemplate.upsert(query, update, IndicatorProvider.class);
    }*/


    public void upsertEventTags(List<SourceEventTag> eventTags){

        DBCollection collection = mongoTemplate.getDb().getCollection("event_tags");
        BulkWriteOperation  bulkWriteOperation= collection.initializeUnorderedBulkOperation();

        for(SourceEventTag eventTag : eventTags)  {
            BasicDBObject query = new BasicDBObject();
            query.append("event_id", eventTag.getEventId());

            BulkWriteRequestBuilder bulkWriteRequestBuilder = bulkWriteOperation.find(query);

            BulkUpdateRequestBuilder updateReq= bulkWriteRequestBuilder.upsert();


            BasicDBObject update = new BasicDBObject();

            update.append("event_id", eventTag.getEventId());

            update.append("event_name", eventTag.getEventName());

            String tagName = eventTag.getTagName();

            if (tagName != null) {
                update.append("tags", (DBObject)com.mongodb.util.JSON.parse(tagName));
            }

            updateReq.replaceOne(update);
        }

        BulkWriteResult result=bulkWriteOperation.execute();

        /*for(IndicatorTag indicatorTag : indicatorTags) {
            Query query = new Query();
            query.addCriteria(Criteria.where("indicator_value").is(indicatorTag.getIndicatorValue()));

            Update update = new Update();

            update.set("tags", indicatorTag.getTags());

            //update.push("indicator_value", indicator.getIndicatorValue());
            //update.set("indicator_type", indicator.getIndicatorType());
            //update.set("confidence", indicator.getConfidence());
            //update.set("country", indicator.getCountry());
            //update.set("city", indicator.getCity());
            //update.set("latitue", indicator.getLatitue());
            //update.set("longitude", indicator.getLongitude());

            mongoTemplate.upsert(query, update, IndicatorTag.class);
        }*/
    }
}
