package com.datapot.indicator.repository;

import com.datapot.indicator.bean.SourceGalaxy;
import com.datapot.indicator.bean.SourceGalaxyCluster;
import com.mongodb.*;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.data.mongodb.core.MongoTemplate;
import org.springframework.stereotype.Component;

import java.util.List;


//necessary imports
/**
 * spring data jpa实现数据访问层；
 */
@Component
public class GalaxyRepository {

    private MongoTemplate mongoTemplate;
    @Autowired
    public void setMongoTemplate(MongoTemplate mongoTemplate) {
        this.mongoTemplate = mongoTemplate;
    }

    public void upsertGalaxies(List<SourceGalaxy> galaxies){

        try {
            DBCollection collection = mongoTemplate.getDb().getCollection("galaxies");
            BulkWriteOperation bulkWriteOperation = collection.initializeUnorderedBulkOperation();

            for (SourceGalaxy galaxy : galaxies) {
                BasicDBObject query = new BasicDBObject();
                query.append("galaxy_id", galaxy.getId());

                BulkWriteRequestBuilder bulkWriteRequestBuilder = bulkWriteOperation.find(query);

                BulkUpdateRequestBuilder updateReq = bulkWriteRequestBuilder.upsert();


                BasicDBObject update = new BasicDBObject();

                update.append("galaxy_id", galaxy.getId());

                update.append("uuid", galaxy.getUuid());
                update.append("name", galaxy.getName());
                update.append("type", galaxy.getType());
                update.append("description", galaxy.getDescription());
                update.append("version", galaxy.getVersion());

                update.append("icon", galaxy.getIcon());

                update.append("namespace", galaxy.getNamespace());
                update.append("kill_chain_order", galaxy.getKillChainOrder());


                updateReq.replaceOne(update);
            }

            bulkWriteOperation.execute();
        }catch (Exception e){
            e.printStackTrace();
        }
    }

    public void upsertGalaxyClusters(List<SourceGalaxyCluster> clusters){

        DBCollection collection = mongoTemplate.getDb().getCollection("galaxy_clusters");
        BulkWriteOperation  bulkWriteOperation= collection.initializeUnorderedBulkOperation();

        for(SourceGalaxyCluster cluster : clusters) {
            BasicDBObject query = new BasicDBObject();
            query.append("galaxy_cluster_id", cluster.getId());
            BulkWriteRequestBuilder bulkWriteRequestBuilder = bulkWriteOperation.find(query);
            BulkUpdateRequestBuilder updateReq= bulkWriteRequestBuilder.upsert();
            BasicDBObject update = new BasicDBObject();
            update.append("galaxy_cluster_id", cluster.getId());

            update.append("uuid", cluster.getUuid());
            update.append("collection_uuid", cluster.getCollectionUuid());
            update.append("type", cluster.getType());
            update.append("value", cluster.getValue());
            update.append("tag_name", cluster.getTagName());
            update.append("description", cluster.getDescription());
            update.append("galaxy_id", cluster.getGalaxyId());
            update.append("source", cluster.getSource());
            update.append("authors", cluster.getAuthors());
            update.append("version", cluster.getVersion());

            updateReq.replaceOne(update);
        }

        BulkWriteResult result=bulkWriteOperation.execute();
    }
}
