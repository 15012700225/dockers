package com.datapot.indicator.repository;

import com.datapot.indicator.bean.SourceIndicatorTag;
import com.datapot.indicator.domain.Indicator;
import com.datapot.indicator.domain.IndicatorProvider;
import com.datapot.indicator.domain.IndicatorTag;
import com.datapot.indicator.domain.Job;
import com.mongodb.*;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.data.mongodb.core.query.Criteria;
import org.springframework.data.mongodb.core.query.Query;
import org.springframework.data.mongodb.core.MongoTemplate;
import org.springframework.data.mongodb.core.query.Update;
import org.springframework.stereotype.Component;

import java.util.*;


//necessary imports


/**
 * spring data jpa实现数据访问层；
 */
@Component
public class IndicatorRepository {

    private MongoTemplate mongoTemplate;
    @Autowired
    public void setMongoTemplate(MongoTemplate mongoTemplate) {
        this.mongoTemplate = mongoTemplate;
    }

    public void upsertIndicators(List<Indicator> indicators){
        try {
            com.mongodb.DBCollection collection = mongoTemplate.getDb().getCollection("indicators");
            BulkWriteOperation bulkWriteOperation = collection.initializeUnorderedBulkOperation();

            for (Indicator indicator : indicators) {
                BasicDBObject query = new BasicDBObject();
                query.append("indicator_value", indicator.getIndicatorValue());

                BulkWriteRequestBuilder bulkWriteRequestBuilder = bulkWriteOperation.find(query);

                BulkUpdateRequestBuilder updateReq = bulkWriteRequestBuilder.upsert();

                BasicDBObject update = new BasicDBObject();

                update.append("indicator_value", indicator.getIndicatorValue());
                update.append("indicator_type", indicator.getIndicatorType());

                if (indicator.getConfidence() != null) {
                    update.append("confidence", indicator.getConfidence());
                }
                if (indicator.getCountry() != null) {
                    update.append("country", indicator.getCountry());
                }

                if (indicator.getCity() != null) {
                    update.append("city", indicator.getCity());
                }

                if(indicator.getLatitude() != null) {
                    update.append("latitude", indicator.getLatitude());
                }
                if(indicator.getLongitude() != null) {
                    update.append("longitude", indicator.getLongitude());
                }

                /*if(indicator.getDescription() != null) {
                    update.append("description", indicator.getDescription());
                }*/

                if (indicator.getDescription() != null) {
                    update.append("description", indicator.getDescription().replaceAll("\r|\n", ""));
                }

                if (indicator.getProvider() != null) {
                    update.append("provider", indicator.getProvider());
                }

                if (indicator.getReportTime() != null) {
                    update.append("report_time", indicator.getReportTime());
                }

                if (indicator.getTimezone() != null) {
                    update.append("timezone", indicator.getTimezone());
                }

                if (indicator.getRegion() != null) {
                    update.append("region", indicator.getRegion());
                }



                updateReq.replaceOne(update);
            }

            BulkWriteResult result = bulkWriteOperation.execute();
        }catch (Exception e){
            e.printStackTrace();
        }
    }

    public void upsertIndicatorProviders(String source, List<IndicatorProvider> providers){

        com.mongodb.DBCollection collection = mongoTemplate.getDb().getCollection("indicator_providers");
        BulkWriteOperation  bulkWriteOperation= collection.initializeUnorderedBulkOperation();

        for(IndicatorProvider provider : providers) {
            BasicDBObject query = new BasicDBObject();
            query.append("indicator_value", provider.getIndicatorValue());
            query.append("provider", provider.getProvider());
            query.append("report_time", provider.getReportTime());

            BulkWriteRequestBuilder bulkWriteRequestBuilder = bulkWriteOperation.find(query);
            BulkUpdateRequestBuilder updateReq= bulkWriteRequestBuilder.upsert();

            BasicDBObject update = new BasicDBObject();
            update.append("indicator_value", provider.getIndicatorValue());
            update.append("source", source);
            update.append("provider", provider.getProvider());
            update.append("report_time", provider.getReportTime());
            update.append("description", provider.getDescription());

           /* if (provider.getDescription() != null) {
                update.append("description", provider.getDescription().replaceAll("\r|\n", ""));
            }*/
            update.append("event_id", provider.getEventId());
            update.append("event_name", provider.getEventName());

            updateReq.replaceOne(update);
        }

        BulkWriteResult result=bulkWriteOperation.execute();
    }

    public void upsertIndicatorTags(Map<String, String> tags){
        com.mongodb.DBCollection collection = mongoTemplate.getDb().getCollection("indicators");
        BulkWriteOperation  bulkWriteOperation= collection.initializeUnorderedBulkOperation();

        List<String> indicatorValues = new ArrayList<>(tags.size());

        for (Map.Entry<String, String> entry : tags.entrySet()) {
            indicatorValues.add(entry.getKey());
        }

        Map<String, Indicator> indicators = getIndicators(indicatorValues);

        boolean execute = false;
        for (Map.Entry<String, String> entry : tags.entrySet()) {
            String indicatorValue = entry.getKey();

            BasicDBObject query = new BasicDBObject();
            query.append("indicator_value", indicatorValue);

            BulkWriteRequestBuilder bulkWriteRequestBuilder = bulkWriteOperation.find(query);

            BulkUpdateRequestBuilder updateReq= bulkWriteRequestBuilder.upsert();

            String tagName = entry.getValue();

            if (indicators.containsKey(indicatorValue)){
                Indicator indicator = indicators.get(indicatorValue);
                String t = indicator.getTags();

                if (t!= null){
                    if(t.contains(tagName)){
                        continue;
                    }
                    else {
                        tagName = t + ","  +  tagName;
                    }
                }
            }

            execute = true;
            updateReq.updateOne(new BasicDBObject("$set", new BasicDBObject("tags", tagName)));
        }

        if(execute) {
            BulkWriteResult result = bulkWriteOperation.execute();
        }
    }


    public Map<String, Indicator> getIndicators(List<String> indicatorValues){

        Query query = new Query();
        query.addCriteria(Criteria.where("indicator_value").in(indicatorValues));

        List<Indicator> indicators  = mongoTemplate.find(query, Indicator.class, "indicators");

        Map<String, Indicator> map = new HashMap<>();
        indicators.forEach(e -> map.put(e.getIndicatorValue(), e));

        return map;
    }

    public Indicator getIndicator(String indicatorValues){
        Query query = new Query();
        query.addCriteria(Criteria.where("indicator_value").in(indicatorValues));

        return mongoTemplate.findOne(query, Indicator.class, "indicators");
    }
}
