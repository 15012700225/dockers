package com.datapot.indicator.repository;

import com.datapot.indicator.domain.Indicator;
import com.datapot.indicator.domain.Job;
import com.datapot.indicator.domain.JobScheduler;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.data.mongodb.core.MongoTemplate;
import org.springframework.data.mongodb.core.query.Criteria;
import org.springframework.data.mongodb.core.query.Query;
import org.springframework.data.mongodb.core.query.Update;
import org.springframework.stereotype.Component;

import java.util.List;

@Component
public class JobRepository {
    private MongoTemplate mongoTemplate;
    @Autowired
    public void setMongoTemplate(MongoTemplate mongoTemplate) {
        this.mongoTemplate = mongoTemplate;
    }

    public Job getJobByJobKey(String jobSchedulerId, String key){
        Query query = new Query();
        query.addCriteria(Criteria.where("job_key").in(jobSchedulerId +"_"+ key));
        return  mongoTemplate.findOne(query, Job.class);
    }

    public void upsertJob(Job job){
        Query query = new Query();
        query.addCriteria(Criteria.where("job_key").is(job.getJobKey()));
        Update update = new Update();
        update.set("status", job.getStatus());
        update.set("retry_times", job.getRetryTimes());
        update.set("description", job.getDescription());
        update.set("product_total", job.getProductTotal());
        update.set("consume_total", job.getConsumeTotal());
        update.set("duration", job.getDuration());
        update.set("createdAt", job.getCreatedAt());
        update.set("updated_at", job.getUpdatedAt());
        update.set("created_by", job.getCreatedBy());
        update.set("updated_by", job.getUpdatedBy());
        update.set("version", job.getVersion());
        mongoTemplate.upsert(query, update, Job.class);
    }


    public void processProductStatus(Job job, long size){
        Query query = new Query();
        query.addCriteria(Criteria.where("job_key").is(job.getJobKey()));
        Update update = new Update();

        update.inc("product_total", size);

        update.set("version", job.getVersion() + 1);
        mongoTemplate.upsert(query, update, Job.class);
    }

    public void processConsumeStatus(Job job, long size){
        Query query = new Query();
        query.addCriteria(Criteria.where("job_key").is(job.getJobKey()));
        Update update = new Update();

        update.inc("consume_total", size);
        update.set("version", job.getVersion() + 1);
        mongoTemplate.upsert(query, update, Job.class);

    }

    public void upsertIndicators(List<Indicator> indicators){

        for(Indicator indicator : indicators) {
            Query query = new Query();
            query.addCriteria(Criteria.where("indicator_value").is(indicator.getIndicatorValue()));

            Update update = new Update();

            update.set("indicator_type", indicator.getIndicatorType());
            update.set("confidence", indicator.getConfidence());
            update.set("country", indicator.getCountry());
            update.set("city", indicator.getCity());
            update.set("latitude", indicator.getLatitude());
            update.set("longitude", indicator.getLongitude());

            mongoTemplate.upsert(query, update, Indicator.class);
        }
    }


    public JobScheduler getJobByJobSource(String jobSource){
        Query query = new Query();
        query.addCriteria(Criteria.where("job_source").in(jobSource));
        return  mongoTemplate.findOne(query, JobScheduler.class);
    }

    public void upsertJobScheduler(JobScheduler jobScheduler){
        Query query = new Query();
        query.addCriteria(Criteria.where("job_source").is(jobScheduler.getJobSource()));
        Update update = new Update();
        update.set("status", jobScheduler.getStatus());

        //update.set("retry_times", jobScheduler.getRetryTimes());
        update.set("description", jobScheduler.getDescription());
        update.set("progressing_flag", jobScheduler.getProgressingFlag());
        update.set("delta_timestamp", jobScheduler.getDeltaTimestamp());
        update.set("createdAt", jobScheduler.getCreatedAt());
        update.set("updated_at", jobScheduler.getUpdatedAt());
        update.set("created_by", jobScheduler.getCreatedBy());
        update.set("updated_by", jobScheduler.getUpdatedBy());
        update.set("version", jobScheduler.getVersion());
        mongoTemplate.upsert(query, update, JobScheduler.class);
    }
}
