package com.datapot.indicator.service;

public interface CifIndicatorETLService {
    void run() throws InterruptedException;
}
