package com.datapot.indicator.service;

public interface CifIndicatorTagETLService {
    void run() throws InterruptedException;
}
