package com.datapot.indicator.service;

public interface HuaweiIndicatorETLService {
    void run() throws InterruptedException;
}
