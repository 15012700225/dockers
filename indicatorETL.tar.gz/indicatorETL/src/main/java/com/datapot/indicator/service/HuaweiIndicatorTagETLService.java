package com.datapot.indicator.service;

public interface HuaweiIndicatorTagETLService {
    void run() throws InterruptedException;
}
