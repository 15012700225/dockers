package com.datapot.indicator.service;

public interface IntelStackIndicatorETLService {
    void run() throws InterruptedException;
}
