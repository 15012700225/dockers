package com.datapot.indicator.service;

public interface MispEventETLService {
    void run();
}
