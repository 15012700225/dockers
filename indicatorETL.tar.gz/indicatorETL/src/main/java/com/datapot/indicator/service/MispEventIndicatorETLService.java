package com.datapot.indicator.service;

public interface MispEventIndicatorETLService {
    void run();
}
