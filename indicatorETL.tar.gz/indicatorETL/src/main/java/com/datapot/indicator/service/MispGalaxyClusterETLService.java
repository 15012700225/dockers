package com.datapot.indicator.service;

public interface MispGalaxyClusterETLService {
    void run();
}
