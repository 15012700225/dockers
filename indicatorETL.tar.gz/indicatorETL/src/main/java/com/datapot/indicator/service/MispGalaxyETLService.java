package com.datapot.indicator.service;

public interface MispGalaxyETLService {
    void run();
}
