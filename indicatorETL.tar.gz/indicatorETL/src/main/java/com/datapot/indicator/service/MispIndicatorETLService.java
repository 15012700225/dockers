package com.datapot.indicator.service;

public interface MispIndicatorETLService {
    void run() throws InterruptedException;
}
