package com.datapot.indicator.service;

public interface MispIndicatorTagETLService {
    void run();
}
