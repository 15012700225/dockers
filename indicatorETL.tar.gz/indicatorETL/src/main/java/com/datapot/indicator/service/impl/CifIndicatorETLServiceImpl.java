package com.datapot.indicator.service.impl;

import com.datapot.indicator.bean.SourceIndicator;
import com.datapot.indicator.config.CifIndicatorTypeMappingConfig;
import com.datapot.indicator.dao.CifDao;
import com.datapot.indicator.domain.Indicator;
import com.datapot.indicator.domain.IndicatorProvider;
import com.datapot.indicator.domain.Job;
import com.datapot.indicator.domain.JobScheduler;
import com.datapot.indicator.repository.IndicatorRepository;
import com.datapot.indicator.service.CifIndicatorETLService;
import com.datapot.indicator.utils.GeoIP2Util;
import com.datapot.indicator.utils.JobUtil;
import com.maxmind.geoip2.exception.GeoIp2Exception;
import io.reactivex.*;
import io.reactivex.schedulers.Schedulers;
import org.apache.commons.collections4.ListUtils;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import java.io.IOException;
import java.util.ArrayList;
import java.util.List;
import java.util.Map;
import java.util.concurrent.CountDownLatch;
import java.util.concurrent.Executors;

@Service
public class CifIndicatorETLServiceImpl implements CifIndicatorETLService {

    private IndicatorRepository indicatorRepository;

    private CifDao cifDao;

    private CifIndicatorTypeMappingConfig indicatorTypeMappingConfig;

    private static final Logger logger = LoggerFactory.getLogger(CifIndicatorETLServiceImpl.class);

    private static final String jobKey = "CIF_INDICATOR_ETL";

    @Override
    public void run() throws InterruptedException {
        JobUtil jobUtil = JobUtil.getInstance();
        Job job = jobUtil.buildJob(jobKey);
        JobScheduler jobScheduler = jobUtil.buildJobScheduler(jobKey);

        //if (jobScheduler.getProgressingFlag() == 1){
        //return;
        //}

        jobUtil.startProcess(jobScheduler,job);
        long now = System.currentTimeMillis()/1000 - jobUtil.getOverlap();

        final CountDownLatch countDownLatch = new CountDownLatch(1);

        Flowable.create((FlowableOnSubscribe<List<SourceIndicator>>) e -> {
            JobUtil jobUtil1 = JobUtil.getInstance();
            Long left = Math.max(0, jobScheduler.getDeltaTimestamp());
            Long limit = 10000L;
            List<SourceIndicator> indicators =  getAttributesByTimestamp(left, limit);

            while(indicators.size() == limit){
                left = indicators.get(indicators.size() - 1).getTimestamp();

                List<List<SourceIndicator>>  partitions = ListUtils.partition(indicators, jobUtil.getPartitionSize());

                for (List<SourceIndicator> partition : partitions) {
                    e.onNext(partition);
                    jobUtil1.inProcessingProduct(job, partition.size());
                }
                indicators =  getAttributesByTimestamp(left, limit);
            }

            if(indicators.size() > 0){
                left = indicators.get(indicators.size() - 1).getTimestamp();
                List<List<SourceIndicator>>  partitions = ListUtils.partition(indicators, jobUtil.getPartitionSize());

                for (List<SourceIndicator> partition : partitions) {
                    e.onNext(partition);
                    jobUtil1.inProcessingProduct(job, partition.size());
                }
            }

           /* while (left <= info.getMax()) {
                for (List<SourceIndicator> partition : getAttributesByTimestampBetween(left)) {
                    e.onNext(partition);
                    jobUtil1.inProcessingProduct(job, partition.size());
                }
                left += jobUtil1.getStepDelta();
            }*/
            e.onComplete();
        }, BackpressureStrategy.BUFFER).subscribeOn(Schedulers.io())
          .observeOn(Schedulers.from(Executors.newFixedThreadPool(jobUtil.getConsumerCount())))
        .subscribe(
          v -> handle(job,v),
          e -> jobUtil.failedProcess(job, e),
          () -> {
              jobScheduler.setDeltaTimestamp(now);
              jobUtil.endProcess(jobScheduler, job);
              countDownLatch.countDown();
          });
        countDownLatch.await();
    }

    private  List<SourceIndicator> getAttributesByTimestamp(long left, long limit){
        JobUtil jobUtil = JobUtil.getInstance();


        List<SourceIndicator> attributes = cifDao.getIndicatorsByReportTime(left, limit, 0);

        logger.info("load indicators : {}", attributes.size());

        return  attributes;
    }

    private void handle(Job job, List<SourceIndicator> attributes){
        JobUtil jobUtil = JobUtil.getInstance();
        List<Indicator> indicators = new ArrayList<>();
        attributes.forEach(attribute -> indicators.add(buildIndicator(attribute)));
        indicatorRepository.upsertIndicators(indicators);

        List<IndicatorProvider> providers = new ArrayList<>();
        attributes.forEach(attribute -> providers.add(buildProvider(attribute)));
        indicatorRepository.upsertIndicatorProviders("CIF", providers);
        jobUtil.inProcessingConsume(job, indicators.size());
    }

    private IndicatorProvider buildProvider(SourceIndicator attribute){
        Map<String,String> types = indicatorTypeMappingConfig.getTypes();

        IndicatorProvider provider = new IndicatorProvider();
        provider.setIndicatorValue(attribute.getIndicator());
        String type = types.get(attribute.getItype());

        provider.setDescription(attribute.getDescription());
        provider.setReportTime(attribute.getReportTime());

        //provider.setProvider("开源网站");

        provider.setProvider(attribute.getProvider());
        provider.setEventId(attribute.getEventId());
        provider.setEventName(attribute.getEventName());
        provider.setDescription(attribute.getDescription());
        provider.setConfidence(attribute.getConfidence());

        return provider;
    }

    private Indicator buildIndicator(SourceIndicator attribute){
        Indicator indicator = new Indicator();
        indicator.setIndicatorValue(attribute.getIndicator());
        //String type = types.get(attribute.getItype());
        Map<String,String> types = indicatorTypeMappingConfig.getTypes();
        String type = types.get(attribute.getItype());

        indicator.setIndicatorType(type);
        indicator.setDescription(attribute.getDescription());
        indicator.setReportTime(attribute.getReportTime());
        indicator.setDescription(attribute.getDescription());
        indicator.setPortList(attribute.getPortList());
        indicator.setTimezone(attribute.getTimezone());
        indicator.setProtocol(attribute.getProtocol());
        indicator.setRegion(attribute.getRegion());
        indicator.setConfidence(5);
        indicator.setCountry(indicator.getCountry());
        indicator.setCity(indicator.getCity());
        indicator.setProvider(indicator.getProvider());

        if (type.equalsIgnoreCase("ipv4/ipv6")) {
            try {
                GeoIP2Util.getInstance().fillinIPinfo(indicator);
            } catch (IOException | GeoIp2Exception e) {
                logger.info(e.getMessage());
            }
        }
        return indicator;
    }


    @Autowired
    public void setIndicatorRepository(IndicatorRepository indicatorRepository) {
        this.indicatorRepository = indicatorRepository;
    }

    @Autowired
    public void setCifDao(CifDao cifDao) {
        this.cifDao = cifDao;
    }

    @Autowired
    public void setIndicatorTypeMappingConfig(CifIndicatorTypeMappingConfig indicatorTypeMappingConfig) {
        this.indicatorTypeMappingConfig = indicatorTypeMappingConfig;
    }
}
