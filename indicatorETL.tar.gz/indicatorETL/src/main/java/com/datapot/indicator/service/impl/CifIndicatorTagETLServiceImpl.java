package com.datapot.indicator.service.impl;

import com.datapot.indicator.bean.SourceIndicatorTag;
import com.datapot.indicator.bean.SourceIndicatorTagSummary;
import com.datapot.indicator.dao.CifDao;

import com.datapot.indicator.domain.IndicatorTag;
import com.datapot.indicator.domain.Job;
import com.datapot.indicator.domain.JobScheduler;
import com.datapot.indicator.repository.IndicatorRepository;
import com.datapot.indicator.service.CifIndicatorTagETLService;
import com.datapot.indicator.utils.JobUtil;
import io.reactivex.*;

import io.reactivex.schedulers.Schedulers;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import java.util.*;
import java.util.concurrent.CountDownLatch;
import java.util.concurrent.Executors;


@Service
public class CifIndicatorTagETLServiceImpl implements CifIndicatorTagETLService {

    private CifDao cifDao;

    private IndicatorRepository indicatorRepository;

    private static final Logger logger = LoggerFactory.getLogger(CifIndicatorTagETLServiceImpl.class);

    private static final String jobKey = "CIF_INDICATOR_TAG_ETL";

    @Override
    public void run() throws InterruptedException {
        JobUtil jobUtil = JobUtil.getInstance();

        Job job = jobUtil.buildJob(jobKey);
        JobScheduler jobScheduler = jobUtil.buildJobScheduler(jobKey);

        jobUtil.startProcess(jobScheduler, job);

        SourceIndicatorTagSummary info = cifDao.getIndicatorTagSummary();
        long stepDelta =  (info.getMax() - info.getMin())/500;

        final CountDownLatch countDownLatch = new CountDownLatch(1);
        Flowable.create((FlowableOnSubscribe<List<SourceIndicatorTag>>) e -> {
            long left  = Math.max(info.getMin(), jobScheduler.getDeltaTimestamp());
            while(left <= info.getMax() ){
                List<SourceIndicatorTag> tags = getAttributeTagsByIndicatorIdBetween(left, left + stepDelta);
                e.onNext(tags);
                jobUtil.inProcessingProduct(job, tags.size());
                left += stepDelta;
            }
            e.onComplete();
        }, BackpressureStrategy.BUFFER).subscribeOn(Schedulers.io())
                .observeOn(Schedulers.from(Executors.newFixedThreadPool(jobUtil.getConsumerCount())))
        .subscribe(
            v -> {
                Map<String, String> indicatorTags = buildIndicatorTags(v);
                indicatorRepository.upsertIndicatorTags(indicatorTags);
                jobUtil.inProcessingConsume(job, v.size());
            },
            e -> jobUtil.failedProcess(job, e),
            () ->{
                jobUtil.endProcess(jobScheduler, job);
                countDownLatch.countDown();
            }
           );
        countDownLatch.await();
    }

    private  List<SourceIndicatorTag> getAttributeTagsByIndicatorIdBetween(long left, long right){

        List<SourceIndicatorTag> attributes = cifDao.getAttributeTagsByIndicatorIdBetween(left, right);

        logger.info("load indicators : {}", attributes.size());

        return  attributes;
    }

    private Map<String, String> buildIndicatorTags(List<SourceIndicatorTag> attributeTags){

        Map<String, String> indicatorTagMap = new HashMap<>();
        for(SourceIndicatorTag attributeTag : attributeTags){

            indicatorTagMap.put(attributeTag.getIndicatorValue(),attributeTag.getTagName());
        }

        return  indicatorTagMap;
    }

    @Autowired
    public void setCifDao(CifDao cifDao) {
        this.cifDao = cifDao;
    }

    @Autowired
    public void setIndicatorRepository(IndicatorRepository indicatorRepository) {
        this.indicatorRepository = indicatorRepository;
    }
}
