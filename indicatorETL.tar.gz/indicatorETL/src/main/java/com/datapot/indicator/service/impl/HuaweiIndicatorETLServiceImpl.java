package com.datapot.indicator.service.impl;


import com.alibaba.fastjson.JSONArray;
import com.alibaba.fastjson.JSONObject;
import com.alibaba.fastjson.JSONReader;
import com.datapot.indicator.bean.SourceIndicator;
import com.datapot.indicator.domain.Indicator;
import com.datapot.indicator.domain.IndicatorProvider;
import com.datapot.indicator.domain.Job;
import com.datapot.indicator.domain.JobScheduler;
import com.datapot.indicator.repository.IndicatorRepository;
import com.datapot.indicator.service.HuaweiIndicatorETLService;
import com.datapot.indicator.utils.GeoIP2Util;
import com.datapot.indicator.utils.JobUtil;
import com.datapot.indicator.utils.JsonUtil;
import com.maxmind.geoip2.exception.GeoIp2Exception;
import io.reactivex.BackpressureStrategy;
import io.reactivex.Flowable;
import io.reactivex.FlowableEmitter;
import io.reactivex.FlowableOnSubscribe;
import io.reactivex.schedulers.Schedulers;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.stereotype.Service;

import java.io.IOException;
import java.io.StringReader;
import java.util.ArrayList;
import java.util.List;
import java.util.Map;
import java.util.concurrent.CountDownLatch;
import java.util.concurrent.Executors;

@Service
public class HuaweiIndicatorETLServiceImpl implements HuaweiIndicatorETLService {

    private IndicatorRepository indicatorRepository;

    private static final Logger logger = LoggerFactory.getLogger(HuaweiIndicatorETLServiceImpl.class);

    private static final String jobKey = "HUAWEI_INDICATOR_ETL";


    @Value("${path.huawei.data}")
    private String JsonFilePath;

    @Override
    public void run() throws InterruptedException {
        JobUtil jobUtil = JobUtil.getInstance();
        Job job = jobUtil.buildJob(jobKey);
        JobScheduler jobScheduler = jobUtil.buildJobScheduler(jobKey);

        //if (jobScheduler.getProgressingFlag() == 1){
        //return;
        //}

        jobUtil.startProcess(jobScheduler,job);
        long now = System.currentTimeMillis()/1000 - jobUtil.getOverlap()/1000;

        final CountDownLatch countDownLatch = new CountDownLatch(1);
        Flowable.create((FlowableOnSubscribe<List<SourceIndicator>>) e -> {
            readWithFastJson(e,  "/ipFeed.json", "ipv4/ipv6");

            readWithFastJson(e, "/urlFeed.json", "url");

            readWithFastJson(e, "/hashFeed.json", "md5");

            readWithFastJson(e, "/domainFeed.json", "domain");
            e.onComplete();
        } , BackpressureStrategy.BUFFER).subscribeOn(Schedulers.io())
          .observeOn(Schedulers.from(Executors.newFixedThreadPool(jobUtil.getConsumerCount())))
        .subscribe(
          v -> handle(job,v),
          e -> jobUtil.failedProcess(job, e),
          () -> {
              jobScheduler.setDeltaTimestamp(now/1000);
              jobUtil.endProcess(jobScheduler, job);
              countDownLatch.countDown();
          });

         countDownLatch.await();
         logger.info("===================================================================");
    }


    private void readWithFastJson(FlowableEmitter e, String fileName, String type)
    {
        // 如果json数据以形式保存在文件中，用FileReader进行流读取！！
        // path为json数据文件路径！！
        // JSONReader reader = new JSONReader(new FileReader(path));

        // 为了直观，方便运行，就用StringReader做示例！

        String path = JsonFilePath + fileName;
        String jsonString = JsonUtil.getInstance().readJsonFile(path);

        JobUtil jobUtil = JobUtil.getInstance();
        List<SourceIndicator> lines = new ArrayList<>(jobUtil.getPartitionSize());

        JSONReader reader = new JSONReader(new StringReader(jsonString));
        reader.startObject();
        while (reader.hasNext())
        {
            String key = reader.readString();

            switch (key){
                case "head":
                case "tagDesc": {
                    reader.startObject();
                    while (reader.hasNext())
                    {
                        reader.readString();
                        reader.readObject().toString();
                    }
                    reader.endObject();
                    break;
                }
                case "reputations":
                {
                    reader.startObject();
                    while (reader.hasNext())
                    {
                        String objectKey = reader.readString();
                        JSONObject object = (JSONObject)reader.readObject();
                        JSONArray tagInfo = object.getJSONArray("tagInfo");

                        //String tagName = "";
                        String confidence = "";
                        for(int i=0;i<tagInfo.size();i++){
                            JSONObject tag = tagInfo.getJSONObject(i);
                            //tagName =  tagName + "," + tag.getString("tag");
                            confidence = tag.getString("confidence");
                        }
                        //tagName = tagName.substring(1);

                        lines.add(buildSourceIndicator(objectKey, type, confidence));

                        if (lines.size() == jobUtil.getPartitionSize()){
                            logger.info("load indicators : {}", lines.size());
                            e.onNext(lines);
                            lines = new ArrayList<>();
                        }
                    }
                    reader.endObject();
                    break;
                }
            }
        }

        if (!lines.isEmpty()){
            logger.info("load indicators : {}", lines.size());
            e.onNext(lines);
            lines = new ArrayList<>();
        }
        reader.endObject();
    }

    private SourceIndicator buildSourceIndicator(String key, String type, String confidenceStr) {

        SourceIndicator indicator = new SourceIndicator();

        indicator.setIndicator(key);
        indicator.setItype(type);
        int confidence  = 3;
        if (confidenceStr.equalsIgnoreCase("high")){
            confidence = 9;
        }
        else if (confidenceStr.equalsIgnoreCase("medium")){
            confidence = 6;
        }
        indicator.setConfidence(confidence);
        //indicator.setDescription(tagName);
        indicator.setProvider("HUAWEI");
        return indicator;
    }

    private void handle(Job job, List<SourceIndicator> attributes){
        JobUtil jobUtil = JobUtil.getInstance();
        List<Indicator> indicators = new ArrayList<>();
        attributes.forEach(attribute -> indicators.add(buildIndicator(attribute)));

        indicatorRepository.upsertIndicators(indicators);

        List<IndicatorProvider> providers = new ArrayList<>();

        attributes.forEach(attribute -> providers.add(buildProvider(attribute)));

        indicatorRepository.upsertIndicatorProviders("HUAWEI", providers);

        jobUtil.inProcessingConsume(job, indicators.size());
    }

    private Indicator buildIndicator(SourceIndicator attribute){
        Indicator indicator = new Indicator();
        indicator.setIndicatorValue(attribute.getIndicator());

        String type = attribute.getItype();

        indicator.setDescription(attribute.getDescription());
        indicator.setProvider(attribute.getProvider());
        indicator.setConfidence(attribute.getConfidence());
        indicator.setIndicatorType(type);

        if (type.equalsIgnoreCase("ipv4/ipv6")) {
            try {
                GeoIP2Util.getInstance().fillinIPinfo(indicator);
            } catch (IOException | GeoIp2Exception e) {
                logger.info(e.getMessage());
            }
        }
        return indicator;
    }

    private IndicatorProvider buildProvider(SourceIndicator attribute){
        IndicatorProvider provider = new IndicatorProvider();
        provider.setIndicatorValue(attribute.getIndicator());

        provider.setDescription(attribute.getDescription());
        //provider.setReportTime(new Date(attribute.getTimestamp()));
        provider.setProvider("HUAWEI");

        provider.setEventId(attribute.getEventId());
        provider.setEventName(attribute.getEventName());
        provider.setDescription(attribute.getDescription());
        provider.setConfidence(attribute.getConfidence());

        return provider;
    }

    @Autowired
    public void setIndicatorRepository(IndicatorRepository indicatorRepository) {
        this.indicatorRepository = indicatorRepository;
    }

}
