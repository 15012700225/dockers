package com.datapot.indicator.service.impl;


import com.alibaba.fastjson.JSONArray;
import com.alibaba.fastjson.JSONObject;
import com.alibaba.fastjson.JSONReader;

import com.datapot.indicator.domain.Job;
import com.datapot.indicator.domain.JobScheduler;
import com.datapot.indicator.repository.IndicatorRepository;
import com.datapot.indicator.service.HuaweiIndicatorTagETLService;
import com.datapot.indicator.utils.JobUtil;
import com.datapot.indicator.utils.JsonUtil;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.stereotype.Service;

import java.io.StringReader;
import java.util.HashMap;
import java.util.Map;

@Service
public class HuaweiIndicatorTagETLServiceImpl implements HuaweiIndicatorTagETLService {

    private IndicatorRepository indicatorRepository;

    private static final Logger logger = LoggerFactory.getLogger(HuaweiIndicatorTagETLServiceImpl.class);

    private static final String jobKey = "HUAWEI_INDICATOR_TAG_ETL";

    @Value("${path.huawei.data}")
    private String JsonFilePath;

    @Override
    public void run() throws InterruptedException {
        JobUtil jobUtil = JobUtil.getInstance();
        Job job = jobUtil.buildJob(jobKey);
        JobScheduler jobScheduler = jobUtil.buildJobScheduler(jobKey);

        //if (jobScheduler.getProgressingFlag() == 1){
        //return;
        //}

        jobUtil.startProcess(jobScheduler,job);
        long now = System.currentTimeMillis()/1000 - jobUtil.getOverlap()/1000;

        readWithFastJson("/ipFeed.json", "ipv4/ipv6");

        readWithFastJson("/urlFeed.json", "url");

        readWithFastJson("/hashFeed.json", "md5");

        readWithFastJson( "/domainFeed.json", "domain");

        jobUtil.endProcess(jobScheduler, job);
         logger.info("===================================================================");
    }


    private void readWithFastJson(String fileName, String type)
    {
        // 如果json数据以形式保存在文件中，用FileReader进行流读取！！
        // path为json数据文件路径！！
        // JSONReader reader = new JSONReader(new FileReader(path));

        // 为了直观，方便运行，就用StringReader做示例！

        String path = JsonFilePath + fileName;
        String jsonString = JsonUtil.getInstance().readJsonFile(path);

        JobUtil jobUtil = JobUtil.getInstance();

        Map<String, String> partition = new HashMap<>(2000);

        JSONReader reader = new JSONReader(new StringReader(jsonString));
        reader.startObject();
        while (reader.hasNext())
        {
            String key = reader.readString();

            switch (key){
                case "head":
                case "tagDesc": {
                    reader.startObject();
                    while (reader.hasNext())
                    {
                        reader.readString();
                        reader.readObject().toString();
                    }
                    reader.endObject();
                    break;
                }
                case "reputations":
                {
                    reader.startObject();
                    while (reader.hasNext())
                    {
                        String objectKey = reader.readString();
                        JSONObject object = (JSONObject)reader.readObject();
                        JSONArray tagInfo = object.getJSONArray("tagInfo");

                        String tagName = "";
                        String confidence = "";
                        for(int i=0;i<tagInfo.size();i++){
                            JSONObject tag = tagInfo.getJSONObject(i);
                            tagName =  tagName + "," + tag.getString("tag");
                        }
                        tagName = tagName.substring(1);

                        partition.put(objectKey,tagName);

                        if (partition.size() == jobUtil.getPartitionSize()){
                            indicatorRepository.upsertIndicatorTags(partition);

                            logger.info("import indicator tags : {}", partition.size());
                            partition = new HashMap<>(2000);
                        }
                    }
                    reader.endObject();
                    break;
                }
            }
        }
        reader.endObject();

        if (!partition.isEmpty()){
            indicatorRepository.upsertIndicatorTags(partition);
        }
    }

    @Autowired
    public void setIndicatorRepository(IndicatorRepository indicatorRepository) {
        this.indicatorRepository = indicatorRepository;
    }
}
