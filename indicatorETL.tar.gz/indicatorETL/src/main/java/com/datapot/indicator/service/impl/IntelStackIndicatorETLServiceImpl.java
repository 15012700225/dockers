package com.datapot.indicator.service.impl;

import com.datapot.indicator.bean.SourceIndicator;
import com.datapot.indicator.config.IntelStackIndicatorTypeMappingConfig;
import com.datapot.indicator.domain.Indicator;
import com.datapot.indicator.domain.IndicatorProvider;
import com.datapot.indicator.domain.Job;
import com.datapot.indicator.domain.JobScheduler;
import com.datapot.indicator.repository.IndicatorRepository;
import com.datapot.indicator.service.IntelStackIndicatorETLService;
import com.datapot.indicator.utils.GeoIP2Util;
import com.datapot.indicator.utils.JobUtil;
import com.maxmind.geoip2.exception.GeoIp2Exception;
import io.reactivex.*;
import io.reactivex.schedulers.Schedulers;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.stereotype.Service;

import java.io.IOException;
import java.io.RandomAccessFile;
import java.nio.ByteBuffer;
import java.nio.channels.FileChannel;
import java.nio.charset.StandardCharsets;
import java.util.*;
import java.util.concurrent.CountDownLatch;
import java.util.concurrent.Executors;

@Service
public class IntelStackIndicatorETLServiceImpl implements IntelStackIndicatorETLService {

    private IndicatorRepository indicatorRepository;

    private IntelStackIndicatorTypeMappingConfig indicatorTypeMappingConfig;

    private static final Logger logger = LoggerFactory.getLogger(IntelStackIndicatorETLServiceImpl.class);

    private static final String jobKey = "INTELSTACK_INDICATOR_ETL";


    @Value("${path.intelstack.data}")
    private String intelStackFileName;


    @Override
    public void run() throws InterruptedException {
        JobUtil jobUtil = JobUtil.getInstance();
        Job job = jobUtil.buildJob(jobKey);
        JobScheduler jobScheduler = jobUtil.buildJobScheduler(jobKey);

        //if (jobScheduler.getProgressingFlag() == 1){
        //return;
        //}

        jobUtil.startProcess(jobScheduler,job);
        long now = System.currentTimeMillis()/1000 - jobUtil.getOverlap()/1000;

        final CountDownLatch countDownLatch = new CountDownLatch(1);
        Flowable.create((FlowableOnSubscribe<List<SourceIndicator>>) e -> {
            RandomAccessFile randomAccessFile = new RandomAccessFile(intelStackFileName, "r");
            FileChannel channel = randomAccessFile.getChannel();
            ByteBuffer buffer = ByteBuffer.allocate(1024 * 1024);
            int bytesRead = channel.read(buffer);
            ByteBuffer stringBuffer = ByteBuffer.allocate(20);
            List<SourceIndicator> lines = new ArrayList<>(jobUtil.getPartitionSize());

            boolean isHeader = true;

            //long count = 0; //2434443
            while (bytesRead != -1) {
                buffer.flip();

                while (buffer.hasRemaining()) {
                    byte b = buffer.get();
                    if (b == 10 || b == 13) {
                        stringBuffer.flip();

                        final String line = StandardCharsets.UTF_8.decode(stringBuffer).toString();

                        if (!isHeader){
                            lines.add(buildSourceIndicator(line));
                        }
                        else{
                            isHeader = false;
                        }

                        if (lines.size() == jobUtil.getPartitionSize()){
                            logger.info("load indicators : {}", lines.size());
                            e.onNext(lines);
                            lines = new ArrayList<>();
                        }
                        stringBuffer.clear();
                    } else {
                        if (stringBuffer.hasRemaining())
                            stringBuffer.put(b);
                        else {
                            stringBuffer = reAllocate(stringBuffer);
                            stringBuffer.put(b);
                        }
                    }
                }
                buffer.clear();
                bytesRead = channel.read(buffer);
            }

            if (lines.size()  > 0){
                logger.info("load indicators : {}", lines.size());
                e.onNext(lines);
            }
            randomAccessFile.close();
            e.onComplete();
        } , BackpressureStrategy.BUFFER).subscribeOn(Schedulers.io())
          .observeOn(Schedulers.from(Executors.newFixedThreadPool(jobUtil.getConsumerCount())))
        .subscribe(
          v -> handle(job,v),
          e -> jobUtil.failedProcess(job, e),
          () -> {
              jobScheduler.setDeltaTimestamp(now/1000);
              jobUtil.endProcess(jobScheduler, job);
              countDownLatch.countDown();
          });

         countDownLatch.await();
         logger.info("===================================================================");
    }

    private SourceIndicator buildSourceIndicator(String line) {
        String[] words = line.split("\t");
        SourceIndicator indicator = new SourceIndicator();

        indicator.setIndicator(words[0]);
        indicator.setItype(words[1].replaceFirst("Intel::",""));

        indicator.setDescription(words[2]);
        indicator.setProvider("INTELSTACK");
        return indicator;
    }

    private void handle(Job job, List<SourceIndicator> attributes){
        JobUtil jobUtil = JobUtil.getInstance();
        List<Indicator> indicators = new ArrayList<>();
        attributes.forEach(attribute -> indicators.add(buildIndicator(attribute)));

        indicatorRepository.upsertIndicators(indicators);

        List<IndicatorProvider> providers = new ArrayList<>();

        attributes.forEach(attribute -> providers.add(buildProvider(attribute)));

        indicatorRepository.upsertIndicatorProviders("INTELSTACK", providers);

        jobUtil.inProcessingConsume(job, indicators.size());
    }

    private Indicator buildIndicator(SourceIndicator attribute){
        Indicator indicator = new Indicator();
        indicator.setIndicatorValue(attribute.getIndicator());

        Map<String,String> types = indicatorTypeMappingConfig.getTypes();

        String type = types.get(attribute.getItype());

        indicator.setIndicatorType(type);
        indicator.setDescription(attribute.getDescription());
        indicator.setProvider(attribute.getProvider());
        indicator.setConfidence(attribute.getConfidence());

        if (type.equalsIgnoreCase("ipv4/ipv6")) {
            try {
                GeoIP2Util.getInstance().fillinIPinfo(indicator);
            } catch (IOException | GeoIp2Exception e) {
                logger.info(e.getMessage());
            }
        }
        return indicator;
    }

    private IndicatorProvider buildProvider(SourceIndicator attribute){
        IndicatorProvider provider = new IndicatorProvider();
        provider.setIndicatorValue(attribute.getIndicator());

        provider.setDescription(attribute.getDescription());
        //provider.setReportTime(new Date(attribute.getTimestamp()));
        provider.setProvider("INTELSTACK");

        provider.setEventId(attribute.getEventId());
        provider.setEventName(attribute.getEventName());
        provider.setDescription(attribute.getDescription());
        provider.setConfidence(attribute.getConfidence());

        return provider;
    }

    private static ByteBuffer reAllocate(ByteBuffer stringBuffer) {
        final int capacity = stringBuffer.capacity();
        byte[] newBuffer = new byte[capacity * 2];
        System.arraycopy(stringBuffer.array(), 0, newBuffer, 0, capacity);
        return (ByteBuffer) ByteBuffer.wrap(newBuffer).position(capacity);
    }

    @Autowired
    public void setIndicatorRepository(IndicatorRepository indicatorRepository) {
        this.indicatorRepository = indicatorRepository;
    }

    @Autowired
    public void setIndicatorTypeMappingConfig(IntelStackIndicatorTypeMappingConfig indicatorTypeMappingConfig) {
        this.indicatorTypeMappingConfig = indicatorTypeMappingConfig;
    }
}
