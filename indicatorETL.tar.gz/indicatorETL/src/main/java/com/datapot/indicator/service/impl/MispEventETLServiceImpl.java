package com.datapot.indicator.service.impl;

import com.datapot.indicator.bean.SourceEvent;
import com.datapot.indicator.bean.SourceRecordSummary;
import com.datapot.indicator.config.MispIndicatorTypeMappingConfig;
import com.datapot.indicator.dao.MispDao;

import com.datapot.indicator.domain.Job;
import com.datapot.indicator.domain.JobScheduler;
import com.datapot.indicator.repository.EventRepository;
import com.datapot.indicator.service.MispEventETLService;
import com.datapot.indicator.utils.JobUtil;
import io.reactivex.BackpressureStrategy;
import io.reactivex.Flowable;
import io.reactivex.FlowableOnSubscribe;
import io.reactivex.schedulers.Schedulers;
import org.apache.commons.collections4.ListUtils;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;


import java.util.List;
import java.util.concurrent.CountDownLatch;
import java.util.concurrent.Executors;

@Service
public class MispEventETLServiceImpl implements MispEventETLService {

    private EventRepository eventRepository;

    private MispDao mispDao;

    private static final Logger logger = LoggerFactory.getLogger(MispEventETLServiceImpl.class);

    private static final String jobKey = "MISP_EVENT_ETL";

    @Override
    public void run() {
        JobUtil jobUtil = JobUtil.getInstance();

        Job job = jobUtil.buildJob(jobKey);

        JobScheduler jobScheduler = jobUtil.buildJobScheduler(jobKey);

        //if (jobScheduler.getProgressingFlag() == 1){
        //return;
        //}

        final CountDownLatch countDownLatch = new CountDownLatch(1);
        try{
            jobUtil.startProcess(jobScheduler,job);
            long now = System.currentTimeMillis()/1000 - jobUtil.getOverlap();
            SourceRecordSummary info = mispDao.getEventSummary(0, now );

            Flowable.create((FlowableOnSubscribe<List<SourceEvent>>) e -> {
                long left  = Math.max(info.getMin(), jobScheduler.getDeltaTimestamp());
                while(left <= info.getMax() ){
                    for(List<SourceEvent> partition : getEventsByTimestampBetween(left)) {
                        e.onNext(partition);
                        jobUtil.inProcessingProduct(job, partition.size());
                    }
                    left += jobUtil.getStepDelta();
                }
                e.onComplete();
            }, BackpressureStrategy.BUFFER)
                    .subscribeOn(Schedulers.single())
                    .observeOn(Schedulers.from(Executors.newFixedThreadPool(jobUtil.getConsumerCount())))
                    .subscribe(
                            v -> handle(job, v),
                            e -> jobUtil.failedProcess(job,e),
                            () ->
                                countDownLatch.countDown()
                            );

            countDownLatch.await();

            jobScheduler.setDeltaTimestamp(now);
            jobUtil.endProcess(jobScheduler, job);

            System.out.println("===================================================================");

        }
        catch(Exception e){
            countDownLatch.countDown();
        }
    }

    private  List<List<SourceEvent>> getEventsByTimestampBetween(long left){
        JobUtil jobUtil = JobUtil.getInstance();
        long right = left +  jobUtil.getStepDelta() - 1;

        List<SourceEvent> events = mispDao.getEventsByTimestampBetween(left, right);

        logger.info("load events : {}", events.size());

        return  ListUtils.partition(events, jobUtil.getPartitionSize());
    }

    private void handle(Job job, List<SourceEvent> events){
        eventRepository.upsertEvents(events);

        JobUtil jobUtil = JobUtil.getInstance();

        jobUtil.inProcessingConsume(job, events.size());

    }

    @Autowired
    public void setEventRepository(EventRepository eventRepository) {
        this.eventRepository = eventRepository;
    }

    @Autowired
    public void setMispDao(MispDao mispDao) {
        this.mispDao = mispDao;
    }
}
