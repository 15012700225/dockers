package com.datapot.indicator.service.impl;

import com.datapot.indicator.bean.SourceEventIndicator;
import com.datapot.indicator.bean.SourceIndicator;
import com.datapot.indicator.bean.SourceRecordSummary;
import com.datapot.indicator.config.MispIndicatorTypeMappingConfig;
import com.datapot.indicator.dao.MispDao;
import com.datapot.indicator.domain.Indicator;
import com.datapot.indicator.domain.IndicatorProvider;
import com.datapot.indicator.domain.Job;
import com.datapot.indicator.domain.JobScheduler;
import com.datapot.indicator.repository.EventRepository;
import com.datapot.indicator.repository.IndicatorRepository;
import com.datapot.indicator.service.MispEventIndicatorETLService;
import com.datapot.indicator.utils.GeoIP2Util;
import com.datapot.indicator.utils.JobUtil;
import com.maxmind.geoip2.exception.GeoIp2Exception;
import io.reactivex.BackpressureStrategy;
import io.reactivex.Flowable;
import io.reactivex.FlowableOnSubscribe;
import io.reactivex.schedulers.Schedulers;
import org.apache.commons.collections4.ListUtils;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import java.io.IOException;
import java.util.ArrayList;
import java.util.Date;
import java.util.List;
import java.util.Map;
import java.util.concurrent.CountDownLatch;
import java.util.concurrent.Executors;

@Service
public class MispEventIndicatorETLServiceImpl implements MispEventIndicatorETLService {

    private IndicatorRepository indicatorRepository;

    private EventRepository eventRepository;

    private MispIndicatorTypeMappingConfig indicatorTypeMappingConfig;

    private MispDao mispDao;

    private static final Logger logger = LoggerFactory.getLogger(MispEventIndicatorETLServiceImpl.class);

    private static final String jobKey = "MISP_EVENT_INDICATOR_ETL";

    @Override
    public void run() {
        JobUtil jobUtil = JobUtil.getInstance();

        Job job = jobUtil.buildJob(jobKey);

        JobScheduler jobScheduler = jobUtil.buildJobScheduler(jobKey);

        //if (jobScheduler.getProgressingFlag() == 1){
        //return;
        //}

        final CountDownLatch countDownLatch = new CountDownLatch(1);

        try{
            jobUtil.startProcess(jobScheduler,job);
            long now = System.currentTimeMillis()/1000 - jobUtil.getOverlap();

            Long nextDeltaTimestamp = 0L;

            Flowable.create((FlowableOnSubscribe<List<SourceEventIndicator>>) e -> {
                Long left  = Math.max(0, jobScheduler.getDeltaTimestamp());
                Long limit = 10000L;

                List<SourceEventIndicator> indicators =  getEventIndicatorsByTimestamp(left, limit);
                while(indicators.size() == limit){
                    left = indicators.get(indicators.size() - 1).getTimestamp();

                    List<List<SourceEventIndicator>>  partitions = ListUtils.partition(indicators, jobUtil.getPartitionSize());

                    for (List<SourceEventIndicator> partition : partitions) {
                        e.onNext(partition);
                        jobUtil.inProcessingProduct(job, partition.size());
                    }
                    indicators =  getEventIndicatorsByTimestamp(left, limit);
                }

                if(indicators.size() > 0){
                    left = indicators.get(indicators.size() - 1).getTimestamp();
                    List<List<SourceEventIndicator>>  partitions = ListUtils.partition(indicators, jobUtil.getPartitionSize());

                    for (List<SourceEventIndicator> partition : partitions) {
                        e.onNext(partition);
                        jobUtil.inProcessingProduct(job, partition.size());
                    }
                }
                /*long left  = Math.max(0, jobScheduler.getDeltaTimestamp());
                while(left <= info.getMax() ){
                    for(List<SourceEventIndicator> partition : getEventIndicatorsByTimestamp(left)) {
                        e.onNext(partition);
                        jobUtil.inProcessingProduct(job, partition.size());
                    }
                    left += jobUtil.getStepDelta();
                }*/
                e.onComplete();
            }, BackpressureStrategy.BUFFER)
                    .subscribeOn(Schedulers.single())
                    .observeOn(Schedulers.from(Executors.newFixedThreadPool(jobUtil.getConsumerCount())))
                    .subscribe(
                            v -> handle(job, v),
                            e -> jobUtil.failedProcess(job,e),
                            () ->
                                countDownLatch.countDown()
                            );
            countDownLatch.await();

            jobScheduler.setDeltaTimestamp(now);
            jobUtil.endProcess(jobScheduler, job);

            System.out.println("===================================================================");
        }
        catch(Exception e){
            countDownLatch.countDown();
        }
    }

    private  List<SourceEventIndicator> getEventIndicatorsByTimestamp(long left, long limit){
        JobUtil jobUtil = JobUtil.getInstance();
        long right = left +  jobUtil.getStepDelta() - 1;

        List<SourceEventIndicator> events = mispDao.getEventIndicatorsByTimestamp(left, limit, 0);

        logger.info("load event indicators : {}", events.size());

        return events;

        //return  ListUtils.partition(events, jobUtil.getPartitionSize());
    }

    private void handle(Job job, List<SourceEventIndicator> eventIndicators){
        eventRepository.upsertEventIndicators(eventIndicators);

        ///////////////////////////////////////////////////////////
        //filter and save to indicators table
        ////////////////////////////////////////////////////////////

        handleIndicatorsAndProviders(job, eventIndicators);



        JobUtil jobUtil = JobUtil.getInstance();

        jobUtil.inProcessingConsume(job, eventIndicators.size());
    }


    private void handleIndicatorsAndProviders(Job job, List<SourceEventIndicator> eventIndicators){
        JobUtil jobUtil = JobUtil.getInstance();

        List<Indicator> indicators = new ArrayList<>();
        List<IndicatorProvider> providers = new ArrayList<>();

        Map<String,String> types = indicatorTypeMappingConfig.getTypes();

        for(SourceEventIndicator eventIndicator : eventIndicators){
            if (!types.containsKey(eventIndicator.getType())) {
                continue;
            }

            indicators.add(buildIndicator(eventIndicator));

            providers.add(buildProvider(eventIndicator));
        }

        indicatorRepository.upsertIndicators(indicators);
        indicatorRepository.upsertIndicatorProviders("MISP",providers);

        jobUtil.inProcessingConsume(job, indicators.size());
    }

    private IndicatorProvider buildProvider(SourceEventIndicator attribute){
        Map<String,String> types = indicatorTypeMappingConfig.getTypes();

        IndicatorProvider provider = new IndicatorProvider();
        provider.setIndicatorValue(attribute.getValue1());
        String type = types.get(attribute.getType());

        provider.setDescription(attribute.getDescription());
        provider.setProvider(attribute.getProvider());
        provider.setReportTime(new Date(attribute.getTimestamp()));

        //provider.setDescription(attribute.getDescription());
        //provider.setConfidence(attribute.getConfidence());

        return provider;
    }


    private Indicator buildIndicator(SourceEventIndicator attribute){

        Map<String,String> types = indicatorTypeMappingConfig.getTypes();

        Indicator indicator = new Indicator();
        indicator.setIndicatorValue(attribute.getValue1());
        String type = types.get(attribute.getType());
        indicator.setIndicatorType(type);
        //indicator.setDescription(attribute.get());
        indicator.setReportTime(new Date(attribute.getTimestamp()));

        if (type.equalsIgnoreCase("ipv4/ipv6")) {
            try {
                GeoIP2Util.getInstance().fillinIPinfo(indicator);
            } catch (IOException | GeoIp2Exception e) {
                logger.info(e.getMessage());
            }
        }
        return indicator;
    }

    @Autowired
    public void setIndicatorRepository(IndicatorRepository indicatorRepository) {
        this.indicatorRepository = indicatorRepository;
    }

    @Autowired
    public void setEventRepository(EventRepository eventRepository) {
        this.eventRepository = eventRepository;
    }

    @Autowired
    public void setMispDao(MispDao mispDao) {
        this.mispDao = mispDao;
    }

    @Autowired
    public void setIndicatorTypeMappingConfig(MispIndicatorTypeMappingConfig indicatorTypeMappingConfig) {
        this.indicatorTypeMappingConfig = indicatorTypeMappingConfig;
    }
}
