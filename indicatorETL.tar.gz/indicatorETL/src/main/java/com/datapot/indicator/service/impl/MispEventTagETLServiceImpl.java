package com.datapot.indicator.service.impl;

import com.datapot.indicator.bean.SourceEventTag;
import com.datapot.indicator.dao.MispDao;
import com.datapot.indicator.domain.Job;
import com.datapot.indicator.domain.JobScheduler;
import com.datapot.indicator.repository.EventRepository;
import com.datapot.indicator.service.MispEventTagETLService;

import com.datapot.indicator.utils.JobUtil;
import org.apache.commons.collections4.ListUtils;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import java.util.List;
import java.util.concurrent.CountDownLatch;


@Service
public class MispEventTagETLServiceImpl implements MispEventTagETLService {

    private MispDao mispDao;

    private EventRepository eventRepository;

    private static final Logger logger = LoggerFactory.getLogger(MispEventTagETLServiceImpl.class);

    private static final String jobKey = "MISP_EVENT_TAG_ETL";

    @Override
    public void run() {
        JobUtil jobUtil = JobUtil.getInstance();

        Job job = jobUtil.buildJob(jobKey);

        JobScheduler jobScheduler = jobUtil.buildJobScheduler(jobKey);

        try{

            jobUtil.startProcess(jobScheduler, job);

            List<SourceEventTag> eventTags = getEventTags();

            jobUtil.inProcessingProduct(job, eventTags.size());

            int partitionSize = jobUtil.getPartitionSize();

            List<List<SourceEventTag>> partitions = ListUtils.partition(eventTags, partitionSize);

            for (List<SourceEventTag> partition : partitions) {
               jobUtil.inProcessingConsume(job, partition.size());
               eventRepository.upsertEventTags(partition);
            }

            jobUtil.endProcess(jobScheduler, job);
        }catch (Exception e){
            jobUtil.failedProcess(job, e);
        }
    }

    private  List<SourceEventTag> getEventTags(){
        List<SourceEventTag> attributeTags = mispDao.getEventTags();
        logger.info("load event tags : {}", attributeTags.size());
        return attributeTags;
    }

    @Autowired
    public void setMispDao(MispDao mispDao) {
        this.mispDao = mispDao;
    }

    @Autowired
    public void setEventRepository(EventRepository eventRepository) {
        this.eventRepository = eventRepository;
    }
}
