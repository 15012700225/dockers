package com.datapot.indicator.service.impl;

import com.datapot.indicator.bean.SourceGalaxyCluster;
import com.datapot.indicator.dao.MispDao;
import com.datapot.indicator.domain.Job;
import com.datapot.indicator.domain.JobScheduler;
import com.datapot.indicator.repository.GalaxyRepository;
import com.datapot.indicator.service.MispGalaxyClusterETLService;
import com.datapot.indicator.utils.JobUtil;
import org.apache.commons.collections4.ListUtils;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import java.util.List;

@Service
public class MispGalaxyClusterETLServiceImpl implements MispGalaxyClusterETLService {

    private GalaxyRepository galaxyRepository;

    private MispDao mispDao;

    private static final Logger logger = LoggerFactory.getLogger(MispGalaxyClusterETLServiceImpl.class);

    private static final String jobKey = "MISP_GALAXY_CLUSTER_ETL";

    @Override
    public void run() {
        JobUtil jobUtil = JobUtil.getInstance();

        Job job = jobUtil.buildJob(jobKey);

        JobScheduler jobScheduler = jobUtil.buildJobScheduler(jobKey);

        try{

            jobUtil.startProcess(jobScheduler, job);

            List<SourceGalaxyCluster> clusters = getGalaxyClusters();


            jobUtil.inProcessingProduct(job, clusters.size());

            int partitionSize = jobUtil.getPartitionSize();

            List<List<SourceGalaxyCluster>> partitions = ListUtils.partition(clusters, partitionSize);

            for (List<SourceGalaxyCluster> partition : partitions) {
                jobUtil.inProcessingConsume(job, partition.size());
                galaxyRepository.upsertGalaxyClusters(partition);
            }
            jobUtil.inProcessingConsume(job, clusters.size());
            jobUtil.endProcess(jobScheduler, job);
        }catch (Exception e){
            jobUtil.failedProcess(job, e);
        }
    }

    private  List<SourceGalaxyCluster> getGalaxyClusters(){
        //JobUtil jobUtil = JobUtil.getInstance();

        List<SourceGalaxyCluster> clusters = mispDao.getGalaxyClusters();

        logger.info("load galaxy clusters : {}", clusters.size());

        return clusters;

        //return  ListUtils.partition(galaxies, jobUtil.getPartitionSize());
    }

    @Autowired
    public void setGalaxyRepository(GalaxyRepository galaxyRepository) {
        this.galaxyRepository = galaxyRepository;
    }

    @Autowired
    public void setMispDao(MispDao mispDao) {
        this.mispDao = mispDao;
    }
}
