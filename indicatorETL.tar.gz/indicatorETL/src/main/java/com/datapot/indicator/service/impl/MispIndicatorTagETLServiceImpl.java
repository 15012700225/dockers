package com.datapot.indicator.service.impl;

import com.datapot.indicator.bean.SourceEventTag;
import com.datapot.indicator.bean.SourceIndicatorTag;

import com.datapot.indicator.bean.SourceRecordSummary;
import com.datapot.indicator.dao.MispDao;
import com.datapot.indicator.domain.IndicatorTag;
import com.datapot.indicator.domain.Job;
import com.datapot.indicator.domain.JobScheduler;

import com.datapot.indicator.repository.IndicatorRepository;
import com.datapot.indicator.service.MispIndicatorTagETLService;
import com.datapot.indicator.utils.JobUtil;
import org.apache.commons.collections4.ListUtils;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import java.util.*;

@Service
public class MispIndicatorTagETLServiceImpl implements MispIndicatorTagETLService {

    private MispDao mispDao;

    private IndicatorRepository indicatorRepository;

    private static final Logger logger = LoggerFactory.getLogger(MispIndicatorTagETLServiceImpl.class);

    private static final String jobKey = "MISP_INDICATOR_TAG_ETL";

    @Override
    public void run() {
        JobUtil jobUtil = JobUtil.getInstance();

        Job job = jobUtil.buildJob(jobKey);

        JobScheduler jobScheduler = jobUtil.buildJobScheduler(jobKey);

        try {

            /*jobUtil.startProcess(jobScheduler, job);

            List<SourceIndicatorTag> attributeTags = getAttributeTags();

            jobUtil.inProcessingProduct(job, attributeTags.size());

            List<IndicatorTag> indicatorTags = buildIndicatorTags(attributeTags);

            int partitionSize = jobUtil.getPartitionSize();

            List<List<IndicatorTag>> partitions = ListUtils.partition(indicatorTags, partitionSize);

            for (List<IndicatorTag> partition : partitions) {
               jobUtil.inProcessingConsume(job, partition.size());
                indicatorRepository.upsertIndicatorTags("MISP", partition);
            }

            //jobScheduler.setDeltaTimestamp(startTime);

            jobUtil.endProcess(jobScheduler, job);*/

            //////////////////////////////////////////////////////////////////////
            jobUtil.startProcess(jobScheduler, job);

            SourceRecordSummary info = mispDao.getIndicatorTagSummary();

            long left = info.getMin();

            Map<String, String> tags = new HashMap<>();

            while(left <= info.getMax()) {
                List<SourceIndicatorTag> attributeTags = getAttributeTags(left, left + 10000 - 1 );

                for(SourceIndicatorTag p : attributeTags){
                    String key = p.getIndicatorValue();
                    if (!tags.containsKey(key)){
                        tags.put(key, p.getTagName()) ;
                    }
                    else{
                        tags.put(key, tags.get(key) + "," + p.getTagName()) ;
                    }
                }

                jobUtil.inProcessingProduct(job, attributeTags.size());
                left += 10000;
            }

            Map<String, String> partition = new HashMap<>(2000);

            for (Map.Entry<String, String> entry : tags.entrySet()) {

               partition.put(entry.getKey(), entry.getValue());

                if (partition.size() == 2000){
                    indicatorRepository.upsertIndicatorTags(partition);

                    jobUtil.inProcessingConsume(job, partition.size());
                    partition = new HashMap<>(2000);
                }
            }

            if (!partition.isEmpty()){
                indicatorRepository.upsertIndicatorTags(partition);
            }
            jobUtil.endProcess(jobScheduler, job);
        }catch (Exception e){
            jobUtil.failedProcess(job, e);
        }
    }

    private  List<SourceIndicatorTag> getAttributeTags(long left, long right){
        List<SourceIndicatorTag> attributeTags = mispDao.getIndicatorTags(left, right);
        logger.info("load indicator tags : {}", attributeTags.size());
        return attributeTags;
    }

    @Autowired
    public void setMispDao(MispDao mispDao) {
        this.mispDao = mispDao;
    }

    @Autowired
    public void setIndicatorRepository(IndicatorRepository indicatorRepository) {
        this.indicatorRepository = indicatorRepository;
    }
}
