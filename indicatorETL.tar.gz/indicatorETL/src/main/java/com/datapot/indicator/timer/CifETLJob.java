package com.datapot.indicator.timer;

import com.datapot.indicator.service.CifIndicatorETLService;
import com.datapot.indicator.service.CifIndicatorTagETLService;
import org.quartz.Job;
import org.quartz.JobExecutionContext;
import org.quartz.JobExecutionException;
import org.springframework.beans.factory.annotation.Autowired;

import java.io.Serializable;

public class CifETLJob implements Job, Serializable {

    private static final long serialVersionUID = 7837056247639871250L;

    @Autowired
    private CifIndicatorETLService cifIndicatorETLService;

    @Autowired
    private CifIndicatorTagETLService cifIndicatorTagETLService;

    @Override
    public void execute(JobExecutionContext jobExecutionContext) throws JobExecutionException {
        try {
            cifIndicatorETLService.run();
            cifIndicatorTagETLService.run();
        } catch (InterruptedException e) {
            e.printStackTrace();
        }

     }
}
