package com.datapot.indicator.timer;

import com.datapot.indicator.service.*;
import com.datapot.indicator.service.impl.CifIndicatorETLServiceImpl;
import org.quartz.Job;
import org.quartz.JobExecutionContext;
import org.quartz.JobExecutionException;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;

import java.io.Serializable;

public class IndicatorETLJob implements Job, Serializable {

    private static final long serialVersionUID = 7837056247639871250L;

    private static final Logger logger = LoggerFactory.getLogger(CifIndicatorETLServiceImpl.class);

    @Autowired
    private CifIndicatorETLService cifIndicatorETLService;

    @Autowired
    private CifIndicatorTagETLService cifIndicatorTagETLService;


    @Autowired
    private IntelStackIndicatorETLService intelStackIndicatorETLService;


    @Autowired
    private MispIndicatorETLService mispIndicatorETLService;

    @Autowired
    private MispIndicatorTagETLService mispIndicatorTagETLService;

    @Autowired
    private MispEventETLService mispEventETLService;


    @Autowired
    private MispEventTagETLService mispEventTagETLService;

    @Autowired
    private MispEventIndicatorETLService mispEventIndicatorETLService;


    @Autowired
    private MispGalaxyETLService mispGalaxyETLService;


    @Autowired
    private MispGalaxyClusterETLService mispGalaxyClusterETLService;

    @Autowired
    private HuaweiIndicatorETLService huaweiIndicatorETLService;

    @Autowired
    private HuaweiIndicatorTagETLService huaweiIndicatorTagETLService;


    @Override
    public void execute(JobExecutionContext jobExecutionContext) throws JobExecutionException {
        try {
            //intelStackIndicatorETLService.run();
            cifIndicatorETLService.run();
            //huaweiIndicatorETLService.run();
            mispIndicatorETLService.run();

            //cifIndicatorTagETLService.run();
            //mispIndicatorTagETLService.run();
            //huaweiIndicatorTagETLService.run();
        } catch (Exception e) {
            logger.error("the error {}",e);
        }
    }
}
