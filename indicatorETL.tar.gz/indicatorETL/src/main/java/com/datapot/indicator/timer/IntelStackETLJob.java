package com.datapot.indicator.timer;

import com.datapot.indicator.service.CifIndicatorETLService;
import com.datapot.indicator.service.CifIndicatorTagETLService;
import com.datapot.indicator.service.IntelStackIndicatorETLService;
import io.reactivex.Observable;
import io.reactivex.Observer;
import io.reactivex.annotations.NonNull;
import io.reactivex.disposables.Disposable;
import org.quartz.Job;
import org.quartz.JobExecutionContext;
import org.quartz.JobExecutionException;
import org.springframework.beans.factory.annotation.Autowired;

import java.io.IOException;
import java.io.Serializable;

public class IntelStackETLJob implements Job, Serializable {

    private static final long serialVersionUID = 7837056247639871250L;

    @Autowired
    private IntelStackIndicatorETLService intelStackIndicatorETLService;


    @Override
    public void execute(JobExecutionContext jobExecutionContext) throws JobExecutionException {
        try {
            intelStackIndicatorETLService.run();
        } catch (InterruptedException e) {
            e.printStackTrace();
        }
    }
}
