package com.datapot.indicator.timer;

import com.datapot.indicator.service.*;
import org.quartz.Job;
import org.quartz.JobExecutionContext;
import org.quartz.JobExecutionException;
import org.springframework.beans.factory.annotation.Autowired;

import java.io.Serializable;

public class MispETLJob implements Job, Serializable {

    private static final long serialVersionUID = 7837056247639871250L;

    @Autowired
    private MispIndicatorETLService mispIndicatorETLService;

    @Autowired
    private MispIndicatorTagETLService mispIndicatorTagETLService;

    @Autowired
    private MispEventETLService mispEventETLService;


    @Autowired
    private MispEventTagETLService mispEventTagETLService;

    @Autowired
    private MispEventIndicatorETLService mispEventIndicatorETLService;


    @Autowired
    private MispGalaxyETLService mispGalaxyETLService;


    @Autowired
    private MispGalaxyClusterETLService mispGalaxyClusterETLService;


    @Override
    public void execute(JobExecutionContext jobExecutionContext) throws JobExecutionException {
        //helloWordService.helloWord();
        //mispIndicatorETLService.run();
        //mispIndicatorTagETLService.run();

        //mispEventETLService.run();
        //mispEventTagETLService.run();
        //mispGalaxyETLService.run();
        //mispGalaxyClusterETLService.run();
        mispEventIndicatorETLService.run();

        //mispEventIndicatorTagETLService.run();
        //mispIndicatorTagETLService.run();



        //adLogDao.findAll().stream().map(AssetsInfoBean::getAccount_name).forEach(System.out::println);
    }
}
