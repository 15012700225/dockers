package com.datapot.indicator.utils;

import com.datapot.indicator.config.GeoLite2Config;
import com.datapot.indicator.domain.Indicator;
import com.maxmind.geoip2.DatabaseReader;
import com.maxmind.geoip2.exception.GeoIp2Exception;
import com.maxmind.geoip2.model.CityResponse;
import com.maxmind.geoip2.record.City;
import com.maxmind.geoip2.record.Country;
import com.maxmind.geoip2.record.Location;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Component;

import javax.annotation.PostConstruct;
import java.io.File;
import java.io.IOException;
import java.net.InetAddress;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

@Component
public class GeoIP2Util {
    private File database;
    private DatabaseReader reader;

    private final static Logger logger = LoggerFactory.getLogger(GeoIP2Util.class);

    private static GeoIP2Util instance = new GeoIP2Util();


    private GeoLite2Config geoLite2Config;

    @Autowired
    public void setGeoLite2Config(GeoLite2Config geoLite2Config) {
        this.geoLite2Config = geoLite2Config;
    }

    private GeoIP2Util(){ }

    public static GeoIP2Util getInstance() {
        return instance;
    }

    @PostConstruct
    public void init(){
        instance = this;
        database = new File(this.geoLite2Config.getCityPath());
        try {
            reader = new DatabaseReader.Builder(database).build();
        } catch (IOException e) {
            e.printStackTrace();
        }
    }

    public void fillinIPinfo(Indicator indicator) throws GeoIp2Exception, IOException {
        long now = System.currentTimeMillis();

        InetAddress ipAddress = InetAddress.getByName(indicator.getIndicatorValue());

        CityResponse response = reader.city(ipAddress);

        Country country = response.getCountry();

        indicator.setCountry(country.getNames().get("zh-CN"));

        City city = response.getCity();

        indicator.setCity(city.getName());
        indicator.setConfidence(city.getConfidence());

        Location location = response.getLocation();

        indicator.setLatitude(location.getLatitude());
        indicator.setLongitude(location.getLongitude());
    }
}
