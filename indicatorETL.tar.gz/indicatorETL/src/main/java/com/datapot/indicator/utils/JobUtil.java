package com.datapot.indicator.utils;

import com.datapot.indicator.config.JobSettingConfig;
import com.datapot.indicator.domain.Job;
import com.datapot.indicator.domain.JobScheduler;
import com.datapot.indicator.repository.JobRepository;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Component;

import javax.annotation.PostConstruct;
import java.text.DateFormat;
import java.util.Date;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

@Component
public class JobUtil {
    private JobRepository jobRepository;

    private static JobUtil instance = new JobUtil();

    private JobSettingConfig jobSettingConfig;


    private static final Logger logger = LoggerFactory.getLogger(JobUtil.class);

    @Autowired
    public void setJobRepository(JobRepository jobRepository) {
        this.jobRepository = jobRepository;
    }

    @Autowired
    public void setJobSettingConfig(JobSettingConfig jobSettingConfig) {
        this.jobSettingConfig = jobSettingConfig;
    }

    private JobUtil(){ }

    public static JobUtil getInstance() {
        return instance;
    }

    @PostConstruct
    public void init(){
        instance = this;
    }

    public Job buildJob(String jobKey){

        Job job = jobRepository.getJobByJobKey(jobKey, DateFormat.getDateInstance().format(new Date()));

        if(job == null){
            job  = new Job(jobKey, DateFormat.getDateInstance().format(new Date()));
        }
        return job;
    }

    public JobScheduler buildJobScheduler(String jobKey){
        JobScheduler jobScheduler = jobRepository.getJobByJobSource(jobKey);

        if (jobScheduler == null){
            jobScheduler = new  JobScheduler(jobKey);
        }
        return jobScheduler;
    }

    public void inProcessingProduct(Job job, long size){
        jobRepository.processProductStatus(job, size);
    }

    public void inProcessingConsume(Job job, long size){
        logger.info("{} the consume size: {}",  Thread.currentThread().getName(), size);
        jobRepository.processConsumeStatus(job, size);
    }

    public void startProcess(JobScheduler jobScheduler, Job job){
        logger.info("{} Service Start!!!", job.getJobKey());
        job.setStartTime(System.currentTimeMillis());
        job.setRetryTimes(0);
        job.setStatus(0);
        job.setDescription("");
        job.setCreatedAt(new Date());
        job.setUpdatedAt(new Date());
        job.setProductTotal(0L);
        job.setConsumeTotal(0L);
        job.setVersion(0);
        jobRepository.upsertJob(job);

        /*jobScheduler.setStatus(0);
        jobScheduler.setDescription("");
        jobScheduler.setCreatedAt(new Date());
        jobScheduler.setUpdatedAt(new Date());
        jobScheduler.setProgressingFlag(1);

        jobRepository.upsertJobScheduler(jobScheduler);*/
    }

    public void endProcess(JobScheduler jobScheduler, Job job){
        job.setEndTime(System.currentTimeMillis());
        long duration =  job.getEndTime()  - job.getStartTime();
        logger.info("{} Service end, the duration is {}" , job.getJobKey(), duration);

        job.setDuration(duration);

        job.setStatus(1);
        job.setDescription("");

        job.setUpdatedAt(new Date());
        job.setVersion(job.getVersion() + 1);
        jobRepository.upsertJob(job);

        jobScheduler.setUpdatedAt(new Date());
        jobScheduler.setVersion(job.getVersion() + 1);
        jobScheduler.setProgressingFlag(0);

        jobRepository.upsertJobScheduler(jobScheduler);
    }

     public void failedProcess(Job job, Throwable e){
        logger.error(job.getJobKey() + " Service failed, the error:", e);
        job.setStatus(1);
        job.setDescription(e.getMessage());

        job.setUpdatedAt(new Date());
        job.setVersion(job.getVersion() + 1);
        jobRepository.upsertJob(job);
    }

    public long getOverlap() {
        return jobSettingConfig.getOverlap();
    }

    public long getStepDelta() {
        return jobSettingConfig.getStepDelta();
    }

    public int getConsumerCount(){
        return jobSettingConfig.getConsumerCount();
    }

    public int getPartitionSize(){
        return jobSettingConfig.getPartitionSize();
    }
}