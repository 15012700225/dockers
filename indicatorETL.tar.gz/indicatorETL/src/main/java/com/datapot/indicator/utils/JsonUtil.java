
package com.datapot.indicator.utils;

import com.datapot.indicator.config.JobSettingConfig;
import com.datapot.indicator.domain.Job;
import com.datapot.indicator.domain.JobScheduler;
import com.datapot.indicator.repository.JobRepository;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Component;

import javax.annotation.PostConstruct;
import java.io.*;
import java.text.DateFormat;
import java.util.Date;

@Component
public class JsonUtil {
    private JobRepository jobRepository;

    private static JsonUtil instance = new JsonUtil();

    private JobSettingConfig jobSettingConfig;


    private static final Logger logger = LoggerFactory.getLogger(JsonUtil.class);

    @Autowired
    public void setJobRepository(JobRepository jobRepository) {
        this.jobRepository = jobRepository;
    }

    @Autowired
    public void setJobSettingConfig(JobSettingConfig jobSettingConfig) {
        this.jobSettingConfig = jobSettingConfig;
    }

    private JsonUtil(){ }

    public static JsonUtil getInstance() {
        return instance;
    }

    @PostConstruct
    public void init(){
        instance = this;
    }

    public static String readJsonFile(String fileName) {
        String jsonStr = "";
        try {
            File jsonFile = new File(fileName);
            FileReader fileReader = new FileReader(jsonFile);

            Reader reader = new InputStreamReader(new FileInputStream(jsonFile),"utf-8");
            int ch = 0;
            StringBuffer sb = new StringBuffer();
            while ((ch = reader.read()) != -1) {
                sb.append((char) ch);
            }
            fileReader.close();
            reader.close();
            jsonStr = sb.toString();
            return jsonStr;
        } catch (IOException e) {
            e.printStackTrace();
            return null;
        }
    }
}
