package com.datapot.indicator;

import com.datapot.indicator.config.datasource.DynamicDataSourceRegister;
import org.junit.Test;
//import org.junit.jupiter.api.Test;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.autoconfigure.SpringBootApplication;
import org.springframework.boot.test.context.SpringBootTest;
import org.springframework.context.annotation.Import;
import org.springframework.data.mongodb.core.MongoTemplate;
import org.springframework.data.mongodb.core.aggregation.Aggregation;
import org.springframework.data.mongodb.core.aggregation.LookupOperation;
import org.springframework.data.mongodb.core.aggregation.ProjectionOperation;
import org.springframework.jdbc.core.JdbcTemplate;
import org.springframework.transaction.annotation.EnableTransactionManagement;

import java.util.List;
import java.util.Map;


@SpringBootTest
public class IndicatorETLApplicationTests {

    private MongoTemplate mongoTemplate;
    @Autowired
    public void setMongoTemplate(MongoTemplate mongoTemplate) {
        this.mongoTemplate = mongoTemplate;
    }

	@Test
	public void contextLoads() {
        LookupOperation indicatorsLookup = LookupOperation.newLookup()
                .from("indicator_tags").localField("indicator_value").foreignField("indicator_value").as("tag");
        ProjectionOperation project  = Aggregation.project("description");
        //project.andInclude("_id");
        Aggregation counts = Aggregation.newAggregation(indicatorsLookup, project);

        List<Map> results =  mongoTemplate.aggregate(counts, "indicators", Map.class).getMappedResults();
        //System.out.println(results);
	}
}

