
docker run -d -v /home/volumes/indicator-etl/geolite2:/geo-data -v /home/docker/volumes/cif-data/:/cif-data -v /opt/intel-stack-client/frameworks/intel:/intelstack-data -v /logs:/logs -v /etc/localtime:/etc/localtime -v /home/volumes/indicator-etl/huawei:/huawei-data indicator-etl:2.0.0

