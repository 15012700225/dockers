sudo intel-stack-client nsm bro
sudo intel-stack-client api --ignore-pull ae4e8256-c1f4-4c1b-4136-e50ce78a350d
sudo intel-stack-client list
#sudo intel-stack-client pull --loop --duration=24h
#sudo intel-stack-client pull
sudo intel-stack-client pull
sudo intel-stack-client pull --loop --duration=24h

/bin/sh

