

docker run -d   -v /opt/intel-stack-client:/opt/intel-stack-client intel-stack-client:latest
