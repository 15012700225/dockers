#!/bin/bash
mongo <<EOF
use admin;
db.createUser({ user: 'root', pwd: '123456', roles: [ { role: "userAdminAnyDatabase", db: "admin" } ] });

use indictor;

db.createCollection("jobs")
db.createCollection("job_schedulers")

db.createCollection("indicators");

db.indicators.createIndex({indicator_value:1},{unique:true})
db.indicators.createIndex({indicator_type:1},{unique:false})
db.indicators.createIndex({deleted:1},{unique:false})

db.createCollection("indicator_providers");

db.indicator_providers.createIndex({indicator_value:1, org_source:1,report_time:1},{unique:true})
db.indicator_providers.createIndex({indicator_value:1},{unique:false})


db.createCollection("huawei_indicators");
db.huawei_indicators.createIndex({indicatorValue:1},{unique:true})

db.createCollection("intelstack_indicators");
db.intelstack_indicators.createIndex({indicatorValue:1},{unique:true})

db.createCollection("indicator_tags");
db.indicator_tags.createIndex({source:1,indicator_value:1},{unique:true})


db.createCollection("misp_events");
db.misp_events.createIndex({id:1},{unique:true})

db.createCollection("misp_event_indicators");
db.misp_event_indicators.createIndex({id:1},{unique:true})
db.misp_event_indicators.createIndex({value1:1},{unique:false})
db.misp_event_indicators.createIndex({eventId:1},{unique:false})


db.createCollection("misp_event_tags");
db.misp_event_tags.createIndex({id:1},{unique:true})
db.misp_event_tags.createIndex({eventId:1},{unique:false})


db.createCollection("misp_galaxies");
db.misp_galaxies.createIndex({id:1},{unique:true})


db.createCollection("misp_galaxy_clusters");
db.misp_galaxy_clusters.createIndex({id:1},{unique:true})
db.misp_galaxy_clusters.createIndex({galaxy_id:1},{unique:false})
db.misp_galaxy_clusters.createIndex({tag_name:1},{unique:false})

db.createCollection("indicator_data_versions");

EOF

mongoimport --db indictor --collection indictors --file $WORKSPACE/indictors.json
mongoimport --db indictor --collection jobs --file $WORKSPACE/jobs.json
mongoimport --db indictor --collection job_schedulers --file $WORKSPACE/job_schedulers.json

